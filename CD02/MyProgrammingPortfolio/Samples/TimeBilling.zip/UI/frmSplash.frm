VERSION 5.00
Begin VB.Form frmSplash 
   BackColor       =   &H00FFFFFF&
   BorderStyle     =   0  'None
   ClientHeight    =   4575
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   6735
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4575
   ScaleWidth      =   6735
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Visible         =   0   'False
   Begin VB.CommandButton Command1 
      Caption         =   "&Continue"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4980
      TabIndex        =   2
      Top             =   2370
      Width           =   1335
   End
   Begin VB.Label Label2 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Sample Application"
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   14.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   -1  'True
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   765
      Left            =   4620
      TabIndex        =   4
      Top             =   3330
      Width           =   1935
   End
   Begin VB.Image Image4 
      Height          =   900
      Left            =   120
      Picture         =   "frmSplash.frx":0000
      Top             =   2880
      Width           =   3915
   End
   Begin VB.Image Image3 
      Height          =   255
      Left            =   5100
      Picture         =   "frmSplash.frx":1119
      Top             =   4260
      Width           =   1575
   End
   Begin VB.Image Image2 
      Height          =   675
      Left            =   60
      Picture         =   "frmSplash.frx":147C
      Top             =   3840
      Width           =   3915
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Automate your project time billing"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   4170
      TabIndex        =   3
      Top             =   420
      Width           =   2415
   End
   Begin VB.Label lblWarning 
      BackStyle       =   0  'Transparent
      Caption         =   $"frmSplash.frx":22E9
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1425
      Left            =   450
      TabIndex        =   1
      Tag             =   "Warning"
      Top             =   780
      Width           =   6075
   End
   Begin VB.Label lblProductName 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Product"
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   14.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000005&
      Height          =   345
      Left            =   180
      TabIndex        =   0
      Tag             =   "Product"
      Top             =   60
      Width           =   1245
   End
End
Attribute VB_Name = "frmSplash"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
    Unload Me
End Sub

Private Sub Form_Load()
    lblProductName.Caption = "Shoutsoft Time Billing"
End Sub

Private Sub Form_Paint()
    Dim rc As RECT, hBr As Long
    GetClientRect hwnd, rc
    
    hBr = CreateSolidBrush(TranslateColor(vbWindowText))
    FillRect hDC, rc, hBr
    DeleteObject hBr
    
    InflateRect rc, -3, -3
    rc.Top = rc.Top + 25
    hBr = CreateSolidBrush(TranslateColor(vbWindowBackground))
    FillRect hDC, rc, hBr
    DeleteObject hBr
    
    rc.bottom = rc.Top + 15
    hBr = CreateSolidBrush(&H4EACDA)
    FillRect hDC, rc, hBr
    DeleteObject hBr
    

End Sub
