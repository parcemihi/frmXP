VERSION 5.00
Begin VB.Form frmExpenseCodeList 
   Caption         =   "Expense Code List View"
   ClientHeight    =   5190
   ClientLeft      =   1110
   ClientTop       =   345
   ClientWidth     =   7560
   Icon            =   "frmExpenseCodeList.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   5190
   ScaleWidth      =   7560
   WindowState     =   2  'Maximized
   Begin TimeBillingUI.DataEditGrid DataEditGrid1 
      Align           =   2  'Align Bottom
      Height          =   3945
      Left            =   0
      TabIndex        =   0
      Top             =   1245
      Width           =   7560
      _ExtentX        =   13335
      _ExtentY        =   7752
   End
   Begin TimeBillingUI.CaptionBar CaptionBar1 
      Align           =   1  'Align Top
      Height          =   435
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   7560
      _ExtentX        =   13335
      _ExtentY        =   767
      Border          =   3
      ForeColor       =   -2147483643
      Picture         =   "frmExpenseCodeList.frx":380A
      Caption         =   "Caption Bar1 "
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   10.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty SubCaptionFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      SubCaptionForeColor=   8438015
   End
End
Attribute VB_Name = "frmExpenseCodeList"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Implements iForm
Private Const mcstrMod$ = "frmExpenseCodeList"
Private m_ExpenseCodes As ExpenseCodes
Private m_ExpenseCode As ExpenseCode
Private m_EnableAttr As ToolBarItems
Private m_FindSubTools As cFindSubTools

Private Sub LoadRecords()
    On Error GoTo Err_LoadRecords
    m_EnableAttr = iForm_Attributes    
    Set m_ExpenseCode = New ExpenseCode
    Set m_ExpenseCodes = m_ExpenseCode.LoadList
    Set Me.DataEditGrid1.DataSource = m_ExpenseCodes
    EnableToolbar False
Done_LoadRecords:
    Exit Sub
Err_LoadRecords:
    ErrorMsg Err.Number, Err.Description, "LoadRecords", mcstrMod
    Resume Done_LoadRecords
End Sub

Private Sub EnableToolbar(ByVal Dirty As Boolean)
    On Error Resume Next
    If Not Dirty Then
        If m_EnableAttr And tbSave Then m_EnableAttr = m_EnableAttr Xor tbSave
        If m_EnableAttr And tbCancel Then m_EnableAttr = m_EnableAttr Xor tbCancel
        'If Not (m_EnableAttr And tbDel) Then m_EnableAttr = m_EnableAttr Or tbDel
        If Not (m_EnableAttr And tbRefresh) Then m_EnableAttr = m_EnableAttr Or tbRefresh
        If Not (m_EnableAttr And tbFind) Then m_EnableAttr = m_EnableAttr Or tbFind
        If Not (m_EnableAttr And tbShowFormView) Then m_EnableAttr = _
            m_EnableAttr Or tbShowFormView
    Else
        If Not (m_EnableAttr And tbSave) Then m_EnableAttr = m_EnableAttr Or tbSave
        If Not (m_EnableAttr And tbCancel) Then m_EnableAttr = m_EnableAttr Or tbCancel
        'If m_EnableAttr And tbDel Then m_EnableAttr = m_EnableAttr Xor tbDel
        If m_EnableAttr And tbRefresh Then m_EnableAttr = m_EnableAttr Xor tbRefresh
        If m_EnableAttr And tbFind Then m_EnableAttr = m_EnableAttr Xor tbFind
        If m_EnableAttr And tbShowFormView Then m_EnableAttr = _
            m_EnableAttr Xor tbShowFormView
    End If
    m_Toolbar.RefreshEnabledState
End Sub

Private Sub DataEditGrid1_Dirty()
    EnableToolbar True
End Sub

Private Sub DataEditGrid1_FetchColumnSetup(ColName As String, ControlType As FieldControlType, ComboMaskList As String, Alignment As FieldControlAlign, Hidden As Boolean, AutoNumber As Boolean)
    On Error Resume Next
    Select Case ColName
    	Case "ExpenseCode"
            ColName = "Expense Code"
            AutoNumber = False
            Alignment = 0
    	Case "ExpenseCodeID"
            ColName = "Expense Code ID"
            AutoNumber = True
            Alignment = 2	
    End Select   
End Sub

Private Sub DataEditGrid1_Move(ByVal Record As Long, ByVal RecordCount As Long)
    Dim strCaption As String
    strCaption = "Record Position: " & Record & " Of " & RecordCount
    If CaptionBar1.SubCaption <> strCaption Then CaptionBar1.SubCaption = strCaption
End Sub

Private Sub Form_Activate()
    m_Toolbar.Activate Name
End Sub

Private Sub Form_Load()
    On Error Resume Next
    m_Toolbar.Attach Me, Name
    
    LoadRecords
    ThinBorder DataEditGrid1.hwnd, False
    CaptionBar1.Caption = Caption
    Set CaptionBar1.Picture = Icon
    
    SetFindSubTools
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    If m_EnableAttr And tbSave Then
        Select Case MsgBox("Record has been changed. Do you want To save it?" _
            , vbYesNoCancel + vbQuestion)
            Case vbYes
                DataEditGrid1.Save
            Case vbNo
            Case vbCancel
                Cancel = True
        End Select
    End If
End Sub

Private Sub Form_Resize()
    On Error Resume Next
    DataEditGrid1.Height = Me.ScaleHeight - (CaptionBar1.Top + CaptionBar1.Height)
End Sub

Private Sub LoadFormView()
    On Error GoTo Err_LoadFormView
    Dim vExpenseCode As New ExpenseCode, frmX As New frmExpenseCode
    vExpenseCode.Load m_ExpenseCodes.Item(DataEditGrid1.CurrentRecord).ExpenseCodeID
    frmX.Component vExpenseCode
    frmX.Show
Done_LoadFormView:
    Exit Sub
Err_LoadFormView:
    If err <> 91 Then ErrorMsg Err.Number, Err.Description, "LoadFormView", mcstrMod
    Resume Done_LoadFormView
End Sub

Private Sub Form_Unload(Cancel As Integer)
    m_Toolbar.Detach Name
End Sub

Private Sub iForm_AddNew()
    Dim vExpenseCode As New ExpenseCode, frmX As New frmExpenseCode
    frmX.Component vExpenseCode
    frmX.Show
End Sub

Private Property Get iForm_Attributes() As ToolBarItems
    iForm_Attributes = tbAddNew + tbCancel + tbCloseMe + tbDel _
        + tbFind + tbRefresh + tbSave + tbShowFormView + tbPrint
End Property

Private Sub iForm_Cancel()
    LoadRecords
End Sub

Private Sub iForm_CloseMe()
    Unload Me
End Sub

Private Sub iForm_delete()
    DataEditGrid1.delete
End Sub

Private Sub iForm_DeleteRow()
    'n/a
End Sub

Private Property Get iForm_EnableAttributes() As ToolBarItems
    iForm_EnableAttributes = m_EnableAttr
End Property

Private Sub iForm_Find(ByVal Key As String)
    Dim strSearch As String
    strSearch = GetFindString
    If strSearch <> vbNullString Then
        Set m_ExpenseCode = New ExpenseCode
        Select Case Key 
        End Select
        Set Me.DataEditGrid1.DataSource = m_ExpenseCodes
        EnableToolbar False
    End If
End Sub

Private Property Get iForm_FindSubTools() As cFindSubTools
    Set iForm_FindSubTools = m_FindSubTools
End Property

Private Sub iForm_HelpAbout()
    'n/a
End Sub

Private Sub iForm_MainMenu()
    'n/a
End Sub

Private Function iForm_OpenDB() As Boolean
    'n/a
End Function

Private Sub iForm_PrintOut()
    'n/a
End Sub

Private Sub iForm_Refresh()
    LoadRecords
End Sub

Private Function iForm_Save() As Boolean
    DataEditGrid1.Save  
    iForm_Refresh
    EnableToolbar False
End Function

Private Sub iForm_ShowFormView()
    LoadFormView
End Sub

Private Sub SetFindSubTools()
    Set m_FindSubTools = New cFindSubTools   
End Sub