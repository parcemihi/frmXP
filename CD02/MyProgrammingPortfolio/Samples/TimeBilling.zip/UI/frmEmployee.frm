VERSION 5.00
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomct2.ocx"
Object = "{C932BA88-4374-101B-A56C-00AA003668DC}#1.1#0"; "MSMASK32.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "tabctl32.ocx"
Begin VB.Form frmEmployee 
   Caption         =   "Employee"
   ClientHeight    =   5490
   ClientLeft      =   1110
   ClientTop       =   345
   ClientWidth     =   7470
   Icon            =   "frmEmployee.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Employee"
   MDIChild        =   -1  'True
   ScaleHeight     =   5490
   ScaleWidth      =   7470
   Begin VB.Label lblLabels 
      Caption         =   "Address:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   0
      Left            =   150
      TabIndex        =   2
      Top             =   510
      Width           =   1815
   End
   Begin VB.TextBox Address
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   1
      Top             =   510
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Billing Rate:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   1
      Left            =   150
      TabIndex        =   4
      Top             =   835
      Width           =   1815
   End
   Begin VB.TextBox BillingRate
      Alignment       =   1 
      Height          =   315
      Left            =   2070
      TabIndex        =   3
      Top             =   835
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "City:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   2
      Left            =   150
      TabIndex        =   6
      Top             =   1160
      Width           =   1815
   End
   Begin VB.TextBox City
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   5
      Top             =   1160
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Country:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   3
      Left            =   150
      TabIndex        =   8
      Top             =   1485
      Width           =   1815
   End
   Begin VB.TextBox Country
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   7
      Top             =   1485
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Employee ID(Auto):"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   4
      Left            =   150
      TabIndex        =   10
      Top             =   1810
      Width           =   1815
   End
   Begin VB.TextBox EmployeeID
      BackColor       =   &H8000000F&
      Enabled         =   0   'False 
      Alignment       =   1 
      Height          =   315
      Left            =   2070
      TabIndex        =   9
      Top             =   1810
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Extension:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   5
      Left            =   150
      TabIndex        =   12
      Top             =   2135
      Width           =   1815
   End
   Begin VB.TextBox Extension
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   11
      Top             =   2135
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "First Name:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   6
      Left            =   150
      TabIndex        =   14
      Top             =   2460
      Width           =   1815
   End
   Begin VB.TextBox FirstName
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   13
      Top             =   2460
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Last Name:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   7
      Left            =   150
      TabIndex        =   16
      Top             =   2785
      Width           =   1815
   End
   Begin VB.TextBox LastName
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   15
      Top             =   2785
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Postal Code:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   8
      Left            =   150
      TabIndex        =   18
      Top             =   3110
      Width           =   1815
   End   
   Begin MSMask.MaskEdBox PostalCode 
      Height          =   315
      Left            =   2070
      TabIndex        =   17
      Top             =   3110
      Width           =   3375
      _ExtentX        =   2990
      _ExtentY        =   503
      _Version        =   393216
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      PromptChar      =   "_"
   End 
   Begin VB.Label lblLabels 
      Caption         =   "State:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   9
      Left            =   150
      TabIndex        =   20
      Top             =   3435
      Width           =   1815
   End
   Begin VB.TextBox StateOrProvince
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   19
      Top             =   3435
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Title:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   10
      Left            =   150
      TabIndex        =   22
      Top             =   3760
      Width           =   1815
   End
   Begin VB.TextBox Title
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   21
      Top             =   3760
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Work Phone:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   11
      Left            =   150
      TabIndex        =   24
      Top             =   4085
      Width           =   1815
   End   
   Begin MSMask.MaskEdBox WorkPhone 
      Height          =   315
      Left            =   2070
      TabIndex        =   23
      Top             =   4085
      Width           =   3375
      _ExtentX        =   2990
      _ExtentY        =   503
      _Version        =   393216
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      PromptChar      =   "_"
   End 
   Begin TabDlg.SSTab tabListview 
      Height          =   2895
      Left            =   0
      TabIndex        =   0
      Top             =   4410
      Width           =   7395
      _ExtentX        =   13044
      _ExtentY        =   5106
      _Version        =   393216
      TabOrientation  =   1
      Tabs            =   1
      TabHeight       =   520 
      TabCaption(0)   =   "Time Cards"
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "DataEditGrid1(0)"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).ControlCount=   1       
      Begin TimeBillingUI.DataEditGrid DataEditGrid1 
         Height          =   2145
         Index           =   0
         Left            =   150
         TabIndex        =   1
         Top             =   180
         Width           =   6900
         _extentx        =   12171
         _extenty        =   3784
         AllowAddNew     =   -1
         Grouped         =   0   'False
      End
   End
   Begin TimeBillingUI.CaptionBar CaptionBar1 
      Align           =   1  'Align Top
      Height          =   435
      Left            =   0
      TabIndex        =   5
      Top             =   0
      Width           =   7470
      _extentx        =   13176
      _extenty        =   767
      border          =   4
      forecolor       =   -2147483643
      Caption         =   "ok i am here"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   10.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty SubCaptionFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End   
End
Attribute VB_Name = "frmEmployee"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Implements iForm
Private Const mcstrMod$ = "frmEmployee"
Private m_Employee As COMEXDataSourceSingle, m_Store As COMEXDataSourceSingle
Private m_flgLoading As Boolean
Private m_EnableAttr As ToolBarItems
Private m_Guid As String

Public Sub Component(vEmployee As COMEXDataSourceSingle)
    Set m_Employee = vEmployee
    Set m_Store = m_Employee.CopyMe
    LoadRecords
End Sub

Private Sub EnableToolbar(ByVal Dirty As Boolean)
    On Error Resume Next
    If Not Dirty Then
        If m_EnableAttr And tbSave Then m_EnableAttr = m_EnableAttr Xor tbSave
        If m_EnableAttr And tbCancel Then m_EnableAttr = m_EnableAttr Xor tbCancel
        If Not (m_EnableAttr And tbRefresh) Then m_EnableAttr = m_EnableAttr Or tbRefresh
    Else
        If Not (m_EnableAttr And tbSave) Then m_EnableAttr = m_EnableAttr Or tbSave
        If Not (m_EnableAttr And tbCancel) Then m_EnableAttr = m_EnableAttr Or tbCancel
        If m_EnableAttr And tbRefresh Then m_EnableAttr = m_EnableAttr Xor tbRefresh
    End If
    m_Toolbar.RefreshEnabledState
End Sub

Private Sub LoadRecords()
    On Error GoTo Err_LoadRecords
    
    Dim ctl As Control, i As Long 
    
    m_flgLoading = True
    
    Dim aEmployee As Employee
    Set aEmployee = m_Employee
    
    
    Dim vTimeCards As COMEXDataSource
    Set vTimeCards = aEmployee.TimeCards
    
    
    With m_Employee
        For i = 1 To .GetFieldCount
            On Error Resume Next
            Set ctl = Controls(.GetFieldName(i))
            If Err = 0 Then
                Select Case TypeName(ctl)
                    Case "Label"
                    Case "TextBox", "ComboBox", "MaskEdBox"
                        ctl = .GetData(i)
                    Case "CheckBox"
                    	ctl.Value = abs(.GetData(i))
                    Case "DTPicker"
                        ctl.Value = .GetData(i)
                End Select
            End If
        Next
    End With
    
    Set Me.DataEditGrid1(0).DataSource = vTimeCards
    m_EnableAttr = iForm_Attributes
    EnableToolbar False
    m_flgLoading = False
Done_LoadRecords:
    Exit Sub
Err_LoadRecords:
    ErrorMsg Err.Number, Err.Description, "LoadRecords", mcstrMod
    Resume Done_LoadRecords
End Sub

 
Private Sub Address_Change()
    On Error GoTo Err_Address_Change
    If m_flgLoading Then Exit Sub
    m_Employee.SetDatabyname Address.Name, Address
    EnableToolbar True
    Exit Sub
Err_Address_Change:
    With Address
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Employee.GetDataByName(Address.Name)
    End With
End Sub
Private Sub Address_LostFocus()
    On Error Resume Next
    Address = m_Employee.GetDataByName(Address.Name)
End Sub
 
Private Sub BillingRate_Change()
    On Error GoTo Err_BillingRate_Change
    If m_flgLoading Then Exit Sub
    m_Employee.SetDatabyname BillingRate.Name, BillingRate
    EnableToolbar True
    Exit Sub
Err_BillingRate_Change:
    With BillingRate
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Employee.GetDataByName(BillingRate.Name)
    End With
End Sub
Private Sub BillingRate_LostFocus()
    On Error Resume Next
    BillingRate = m_Employee.GetDataByName(BillingRate.Name)
End Sub
 
Private Sub City_Change()
    On Error GoTo Err_City_Change
    If m_flgLoading Then Exit Sub
    m_Employee.SetDatabyname City.Name, City
    EnableToolbar True
    Exit Sub
Err_City_Change:
    With City
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Employee.GetDataByName(City.Name)
    End With
End Sub
Private Sub City_LostFocus()
    On Error Resume Next
    City = m_Employee.GetDataByName(City.Name)
End Sub
 
Private Sub Country_Change()
    On Error GoTo Err_Country_Change
    If m_flgLoading Then Exit Sub
    m_Employee.SetDatabyname Country.Name, Country
    EnableToolbar True
    Exit Sub
Err_Country_Change:
    With Country
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Employee.GetDataByName(Country.Name)
    End With
End Sub
Private Sub Country_LostFocus()
    On Error Resume Next
    Country = m_Employee.GetDataByName(Country.Name)
End Sub
 
Private Sub EmployeeID_Change()
    On Error GoTo Err_EmployeeID_Change
    If m_flgLoading Then Exit Sub
    m_Employee.SetDatabyname EmployeeID.Name, EmployeeID
    EnableToolbar True
    Exit Sub
Err_EmployeeID_Change:
    With EmployeeID
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Employee.GetDataByName(EmployeeID.Name)
    End With
End Sub
Private Sub EmployeeID_LostFocus()
    On Error Resume Next
    EmployeeID = m_Employee.GetDataByName(EmployeeID.Name)
End Sub
 
Private Sub Extension_Change()
    On Error GoTo Err_Extension_Change
    If m_flgLoading Then Exit Sub
    m_Employee.SetDatabyname Extension.Name, Extension
    EnableToolbar True
    Exit Sub
Err_Extension_Change:
    With Extension
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Employee.GetDataByName(Extension.Name)
    End With
End Sub
Private Sub Extension_LostFocus()
    On Error Resume Next
    Extension = m_Employee.GetDataByName(Extension.Name)
End Sub
 
Private Sub FirstName_Change()
    On Error GoTo Err_FirstName_Change
    If m_flgLoading Then Exit Sub
    m_Employee.SetDatabyname FirstName.Name, FirstName
    EnableToolbar True
    Exit Sub
Err_FirstName_Change:
    With FirstName
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Employee.GetDataByName(FirstName.Name)
    End With
End Sub
Private Sub FirstName_LostFocus()
    On Error Resume Next
    FirstName = m_Employee.GetDataByName(FirstName.Name)
End Sub
 
Private Sub LastName_Change()
    On Error GoTo Err_LastName_Change
    If m_flgLoading Then Exit Sub
    m_Employee.SetDatabyname LastName.Name, LastName
    EnableToolbar True
    Exit Sub
Err_LastName_Change:
    With LastName
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Employee.GetDataByName(LastName.Name)
    End With
End Sub
Private Sub LastName_LostFocus()
    On Error Resume Next
    LastName = m_Employee.GetDataByName(LastName.Name)
End Sub

Private Sub PostalCode_Change()
    On Error GoTo Err_PostalCode_Change
    If m_flgLoading Then Exit Sub
    m_Employee.SetDatabyname PostalCode.Name, PostalCode
    EnableToolbar True
    Exit Sub
Err_PostalCode_Change:
    PostalCode = m_Employee.GetDatabyname(PostalCode.Name)
End Sub 
Private Sub PostalCode_LostFocus()
    On Error Resume Next
    PostalCode = m_Employee.GetDataByName(PostalCode.Name)
End Sub
 
Private Sub StateOrProvince_Change()
    On Error GoTo Err_StateOrProvince_Change
    If m_flgLoading Then Exit Sub
    m_Employee.SetDatabyname StateOrProvince.Name, StateOrProvince
    EnableToolbar True
    Exit Sub
Err_StateOrProvince_Change:
    With StateOrProvince
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Employee.GetDataByName(StateOrProvince.Name)
    End With
End Sub
Private Sub StateOrProvince_LostFocus()
    On Error Resume Next
    StateOrProvince = m_Employee.GetDataByName(StateOrProvince.Name)
End Sub
 
Private Sub Title_Change()
    On Error GoTo Err_Title_Change
    If m_flgLoading Then Exit Sub
    m_Employee.SetDatabyname Title.Name, Title
    EnableToolbar True
    Exit Sub
Err_Title_Change:
    With Title
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Employee.GetDataByName(Title.Name)
    End With
End Sub
Private Sub Title_LostFocus()
    On Error Resume Next
    Title = m_Employee.GetDataByName(Title.Name)
End Sub

Private Sub WorkPhone_Change()
    On Error GoTo Err_WorkPhone_Change
    If m_flgLoading Then Exit Sub
    m_Employee.SetDatabyname WorkPhone.Name, WorkPhone
    EnableToolbar True
    Exit Sub
Err_WorkPhone_Change:
    WorkPhone = m_Employee.GetDatabyname(WorkPhone.Name)
End Sub 
Private Sub WorkPhone_LostFocus()
    On Error Resume Next
    WorkPhone = m_Employee.GetDataByName(WorkPhone.Name)
End Sub



Private Sub tabListview_Click(PreviousTab As Integer)
	
  Me.DataEditGrid1(0).Visible =(tabListview.tab = 0)
  Me.Refresh
End Sub

Private Sub DataEditGrid1_Dirty(Index As Integer)
    EnableToolbar True
End Sub

Private Sub DataEditGrid1_FetchColumnSetup(Index As Integer, ColName As String, ControlType As FieldControlType, ComboMaskList As String, Alignment As FieldControlAlign, Hidden As Boolean, AutoNumber As Boolean)
    Select Case Index    
        Case 0
            Select Case ColName
                Case "EmployeeID"
                    Hidden = True
            End Select
            Dim vTimeCard As New TimeCard
            Select Case ColName 			
                Case "DateEntered"
                    ColName = "Date Entered"
                    AutoNumber = False
                    Alignment = 1
                    ControlType = fcDateTimePick
                Case "EmployeeID"
                    ColName = "Employee ID"
                    AutoNumber = False
                    Alignment = 2
                    ControlType = fcComboBx
                    ComboMaskList = vTimeCard.GetEmployeesList
                Case "TimeCardID"
                    ColName = "TimeCard ID"
                    AutoNumber = True
                    Alignment = 2
            End Select
    End Select	
End Sub

Private Sub Form_Activate()
    m_Toolbar.Activate m_Guid
End Sub

Private Sub Form_Load()
	Dim vEmployee As New Employee, strCombo As String
    m_Guid = GUID
    m_Toolbar.Attach Me, m_Guid

    tabListview_Click 0 
	ThinBorder DataEditGrid1(0).hwnd, False 
    CaptionBar1.Caption = Caption
    Set CaptionBar1.Picture = Me.Icon

	PostalCode.mask = "#####"

	WorkPhone.mask = "(###)###-####"
    
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    If m_EnableAttr And tbSave Then
        Select Case MsgBox("Record has been changed. Do you want To save it?" _
            , vbYesNoCancel + vbQuestion)
            Case vbYes
                m_Employee.Save
            Case vbNo
            Case vbCancel
                Cancel = True
        End Select
    End If
End Sub

Private Sub Form_Resize()    
	On Error Resume Next	
	If Me.WindowState <> vbMinimized Then
	    With CaptionBar1
	        .Move 0, .Top, Me.ScaleWidth, .Height
	    End With 
	    With tabListview
	        .Left = 0
	        .Top = (WorkPhone.Top + WorkPhone.Height + 100)
	        .Height = Me.ScaleHeight - .Top
	        .Width = Me.ScaleWidth
	        DataEditGrid1(0).Move 100, 100, .Width - 200, .Height - 450
	    End With          
	End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    m_Toolbar.Detach m_Guid
End Sub

Private Sub LoadFormView()
    On Error GoTo Err_LoadFormView
    Dim vItem As Object, frmX As Object , aEmployee As Employee
    
    Set aEmployee = m_Employee
    Select Case tabListview.Tab
       	Case 0      
       		Dim vTimeCard As TimeCard
       		Set vItem = New TimeCard
       		Set frmX = New frmTimeCard                                            
       		Set vTimeCard = aEmployee.TimeCards(DataEditGrid1(tabListview.Tab).CurrentRecord)
       		vItem.Load vTimeCard.TimeCardID, True    
    End Select    
    frmX.Component vItem
    frmX.Show
Done_LoadFormView:
    Exit Sub
Err_LoadFormView:
    If err <> 91 Then ErrorMsg Err.Number, Err.Description, "LoadFormView", mcstrMod
    Resume Done_LoadFormView
End Sub

Private Sub iForm_MainMenu()
    'n/a
End Sub

Private Property Get iForm_Attributes() As ToolBarItems
    iForm_Attributes = tbCancel + tbCloseMe + tbRefresh + tbSave   + tbDeleteRow + tbShowFormView
End Property

Private Sub iForm_Cancel()
    Set m_Employee = m_Store.CopyMe
    LoadRecords
End Sub

Private Sub iForm_CloseMe()
    Unload Me
End Sub

Private Sub iForm_delete()
    'n/a
End Sub

Private Property Get iForm_EnableAttributes() As ToolBarItems
    iForm_EnableAttributes = m_EnableAttr
End Property

Private Sub iForm_Find(ByVal Key As String)
    'n/a
End Sub

Private Sub iForm_Refresh()
    Dim aEmployee As Employee
    Set aEmployee = m_Employee
    aEmployee.Load aEmployee.EmployeeID, True
    Set m_Employee = aEmployee
    LoadRecords
End Sub

Private Function iForm_Save() As Boolean
    DataEditGrid1(tabListview.Tab).Update
    If m_Employee.Save Then 
    	Set m_Store = m_Employee.CopyMe
    	iForm_Refresh
    End If
End Function

Private Sub iForm_AddNew()
    'n/a
End Sub

Private Sub iForm_ShowFormView()   
	LoadFormView
End Sub

Private Property Get iForm_FindSubTools() As cFindSubTools
    'n/a
End Property

Private Sub iForm_HelpAbout()
    'n/a
End Sub

Private Function iForm_OpenDB() As Boolean
    'n/a
End Function

Private Sub iForm_DeleteRow()
    DataEditGrid1(tabListview.Tab).delete    
End Sub

Private Sub iForm_PrintOut()
    'n/a
End Sub