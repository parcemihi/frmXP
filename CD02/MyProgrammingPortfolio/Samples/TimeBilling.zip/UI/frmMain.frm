VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomctl.ocx"
Begin VB.MDIForm frmMain 
   BackColor       =   &H8000000C&
   Caption         =   "TimeBillingUI"
   ClientHeight    =   4740
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   7800
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "MDIForm1"
   StartUpPosition =   3  'Windows Default
   Begin TimeBillingUI.MenuTree mtMenus 
      Align           =   3  'Align Left
      Height          =   2820
      Left            =   0
      TabIndex        =   2
      Top             =   1650
      Width           =   2580
      _ExtentX        =   4551
      _ExtentY        =   4974
   End
   Begin MSComctlLib.StatusBar sbStatusBar 
      Align           =   2  'Align Bottom
      Height          =   270
      Left            =   0
      TabIndex        =   0
      Top             =   4470
      Width           =   7800
      _ExtentX        =   13758
      _ExtentY        =   476
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   3
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   8123
            Text            =   "Click ""Form"" on the toolbar to drill down"
            TextSave        =   "Click ""Form"" on the toolbar to drill down"
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Style           =   6
            AutoSize        =   2
            TextSave        =   "2001-1-20"
         EndProperty
         BeginProperty Panel3 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Style           =   5
            AutoSize        =   2
            TextSave        =   "21:20"
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.Toolbar tlBar 
      Align           =   1  'Align Top
      Height          =   1650
      Left            =   0
      Negotiate       =   -1  'True
      TabIndex        =   1
      Top             =   0
      Width           =   7800
      _ExtentX        =   13758
      _ExtentY        =   2910
      ButtonWidth     =   1191
      ButtonHeight    =   953
      Appearance      =   1
      Style           =   1
      ImageList       =   "ImageList1"
      _Version        =   393216
      BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
         NumButtons      =   17
         BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "New"
            Key             =   "New"
            Object.ToolTipText     =   "New"
            ImageKey        =   "New"
         EndProperty
         BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Delete"
            Key             =   "Delete"
            Object.ToolTipText     =   "Delete"
            ImageKey        =   "Delete"
         EndProperty
         BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Save"
            Key             =   "Save"
            Object.ToolTipText     =   "Save"
            ImageKey        =   "Save"
         EndProperty
         BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Cancel"
            Key             =   "Cancel"
            Object.ToolTipText     =   "Cancel"
            ImageKey        =   "Cancel"
         EndProperty
         BeginProperty Button5 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Delete"
            Key             =   "DeleteRow"
            Object.ToolTipText     =   "Delete a Row"
            ImageKey        =   "DeleteRow"
         EndProperty
         BeginProperty Button6 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Refresh"
            Key             =   "Refresh"
            Object.ToolTipText     =   "Refresh"
            ImageKey        =   "Refresh"
         EndProperty
         BeginProperty Button7 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "DBBar"
            Style           =   3
         EndProperty
         BeginProperty Button8 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Print"
            Key             =   "Print"
            Object.ToolTipText     =   "Print"
            ImageKey        =   "Print"
         EndProperty
         BeginProperty Button9 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Find"
            Key             =   "Find"
            Object.ToolTipText     =   "Find"
            ImageKey        =   "Find"
            Style           =   5
         EndProperty
         BeginProperty Button10 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "FINDBar"
            Style           =   3
         EndProperty
         BeginProperty Button11 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Form"
            Key             =   "Form"
            Object.ToolTipText     =   "Show In a Form View"
            ImageKey        =   "Form"
         EndProperty
         BeginProperty Button12 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "FORMBar"
            Style           =   3
         EndProperty
         BeginProperty Button13 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Main"
            Key             =   "Main"
            Object.ToolTipText     =   "Main"
            ImageKey        =   "Main"
            Style           =   1
            Value           =   1
         EndProperty
         BeginProperty Button14 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Open"
            Key             =   "Open"
            Object.ToolTipText     =   "Open a database"
            ImageKey        =   "Open"
         EndProperty
         BeginProperty Button15 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Close"
            Key             =   "Close"
            Object.ToolTipText     =   "Close"
            ImageKey        =   "Close"
         EndProperty
         BeginProperty Button16 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "CLOSEBar"
            Style           =   3
         EndProperty
         BeginProperty Button17 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Help"
            Key             =   "Help"
            Object.ToolTipText     =   "Help"
            ImageKey        =   "Help"
         EndProperty
      EndProperty
      Begin MSComctlLib.ImageList ImageList1 
         Left            =   4950
         Top             =   450
         _ExtentX        =   1005
         _ExtentY        =   1005
         BackColor       =   -2147483643
         ImageWidth      =   16
         ImageHeight     =   16
         MaskColor       =   12632256
         _Version        =   393216
         BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
            NumListImages   =   16
            BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":380A
               Key             =   "New"
            EndProperty
            BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":39E4
               Key             =   "Main"
            EndProperty
            BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":71FE
               Key             =   "DeleteRow"
            EndProperty
            BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":73D8
               Key             =   "Help"
            EndProperty
            BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":75B2
               Key             =   "Open"
            EndProperty
            BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":778C
               Key             =   "Refresh"
            EndProperty
            BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":78E6
               Key             =   "Form"
            EndProperty
            BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":7A40
               Key             =   "Find"
            EndProperty
            BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":7C1A
               Key             =   "Cancel"
            EndProperty
            BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":7DF4
               Key             =   "Close"
            EndProperty
            BeginProperty ListImage11 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":7FCE
               Key             =   "Print"
            EndProperty
            BeginProperty ListImage12 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":81A8
               Key             =   "Delete"
            EndProperty
            BeginProperty ListImage13 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":8382
               Key             =   "Save"
            EndProperty
            BeginProperty ListImage14 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":855C
               Key             =   "Menus"
            EndProperty
            BeginProperty ListImage15 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":8AF6
               Key             =   ""
            EndProperty
            BeginProperty ListImage16 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmMain.frx":9090
               Key             =   "Menu"
            EndProperty
         EndProperty
      End
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuFileNew 
         Caption         =   "&New"
         Shortcut        =   ^N
      End
      Begin VB.Menu mnuFileOpen 
         Caption         =   "&Open..."
         Shortcut        =   ^O
      End
      Begin VB.Menu mnuFileClose 
         Caption         =   "&Close"
      End
      Begin VB.Menu mnuFileBar0 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFileMRU 
         Caption         =   ""
         Index           =   1
         Visible         =   0   'False
      End
      Begin VB.Menu mnuFileMRU 
         Caption         =   ""
         Index           =   2
         Visible         =   0   'False
      End
      Begin VB.Menu mnuFileMRU 
         Caption         =   ""
         Index           =   3
         Visible         =   0   'False
      End
      Begin VB.Menu mnuFileBar2 
         Caption         =   "-"
         Visible         =   0   'False
      End
      Begin VB.Menu mnuFileExit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuView 
      Caption         =   "&View"
      Begin VB.Menu mnuViewStatusBar 
         Caption         =   "Status &Bar"
         Checked         =   -1  'True
      End
   End
   Begin VB.Menu mnuWindow 
      Caption         =   "&Window"
      WindowList      =   -1  'True
      Begin VB.Menu mnuWindowCascade 
         Caption         =   "&Cascade"
      End
      Begin VB.Menu mnuWindowTileHorizontal 
         Caption         =   "Tile &Horizontal"
      End
      Begin VB.Menu mnuWindowTileVertical 
         Caption         =   "Tile &Vertical"
      End
      Begin VB.Menu mnuWindowArrangeIcons 
         Caption         =   "&Arrange Icons"
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "&Help"
      Begin VB.Menu mnuHelpContents 
         Caption         =   "&Contents"
      End
      Begin VB.Menu mnuHelpSearchForHelpOn 
         Caption         =   "&Search For Help On..."
      End
      Begin VB.Menu mnuHelpBar0 
         Caption         =   "-"
      End
      Begin VB.Menu mnuHelpAbout 
         Caption         =   "&About "
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Implements iForm
Private m_EnableAttr As ToolBarItems
Private Const mcstrMod$ = "frmMain"
Private Declare Function OSWinHelp% Lib "user32" Alias "WinHelpA" (ByVal hwnd&, ByVal HelpFile$, ByVal wCommand%, dwData As Any)

Public Sub SetStatus(Optional ByVal StatusText As String = vbNullString)
    On Error Resume Next
    If StatusText = vbNullString Then
        Me.sbStatusBar.Panels(1).Text = "Ready"
    Else
        Me.sbStatusBar.Panels(1).Text = StatusText
    End If
End Sub

Private Sub iForm_AddNew()
    'n.a
End Sub

Private Property Get iForm_Attributes() As ToolBarItems
    m_EnableAttr = tbCloseMe + tbOpen + tbHelp + tbMainMenu
    iForm_Attributes = m_EnableAttr
End Property

Private Sub iForm_Cancel()
    'n.a
End Sub

Private Sub iForm_CloseMe()
    End
End Sub

Private Sub iForm_delete()
    'n.a
End Sub

Private Sub iForm_DeleteRow()
    'n/a
End Sub

Private Property Get iForm_EnableAttributes() As ToolBarItems
    iForm_EnableAttributes = m_EnableAttr
End Property

Private Sub iForm_Find(ByVal Key As String)
    'n.a
End Sub

Private Property Get iForm_FindSubTools() As cFindSubTools
    'n.a
End Property

Private Sub iForm_HelpAbout()
    mnuHelpAbout_Click
End Sub

Private Sub iForm_MainMenu()
    mtMenus.Visible = Not mtMenus.Visible
End Sub

Private Function iForm_OpenDB() As Boolean
    'n/a
End Function

Private Sub iForm_PrintOut()
    'n/a
End Sub

Private Sub iForm_Refresh()
    'n.a
End Sub

Private Function iForm_Save() As Boolean
    'n.a
End Function

Private Sub iForm_ShowFormView()
    'n.a
End Sub

Private Sub MDIForm_Load()
    On Error GoTo Err_MDIForm_Load
    Me.Left = GetSetting(App.Title, "Settings", "MainLeft", 1000)
    Me.Top = GetSetting(App.Title, "Settings", "MainTop", 1000)
    Me.width = GetSetting(App.Title, "Settings", "MainWidth", 6500)
    Me.height = GetSetting(App.Title, "Settings", "MainHeight", 6500)
    
    LoadMenus
    Exit Sub
Err_MDIForm_Load:
        ErrorMsg Err.Number, Err.Description, "MDIForm_Load", mcstrMod
    Exit Sub
End Sub


Private Sub MDIForm_Unload(Cancel As Integer)
        On Error Resume Next
    If Me.WindowState <> vbMinimized Then
        SaveSetting App.Title, "Settings", "MainLeft", Me.Left
        SaveSetting App.Title, "Settings", "MainTop", Me.Top
        SaveSetting App.Title, "Settings", "MainWidth", Me.width
        SaveSetting App.Title, "Settings", "MainHeight", Me.height
    End If
End Sub

Private Sub mnuHelpAbout_Click()
    frmAbout.Show vbModal, Me
End Sub

Private Sub mnuHelpSearchForHelpOn_Click()
    Dim nRet As Integer


    'if there is no helpfile for this project display a message to the user
    'you can set the HelpFile for your application in the
    'Project Properties dialog
    If Len(App.HelpFile) = 0 Then
        MsgBox "Unable To display Help Contents. There is no Help associated With this project.", vbInformation, Me.Caption
    Else
        On Error Resume Next
        nRet = OSWinHelp(Me.hwnd, App.HelpFile, 261, 0)
        If Err Then
            MsgBox Err.Description
        End If
    End If

End Sub

Private Sub mnuHelpContents_Click()
    Dim nRet As Integer


    'if there is no helpfile for this project display a message to the user
    'you can set the HelpFile for your application in the
    'Project Properties dialog
    If Len(App.HelpFile) = 0 Then
        MsgBox "Unable To display Help Contents. There is no Help associated With this project.", vbInformation, Me.Caption
    Else
        On Error Resume Next
        nRet = OSWinHelp(Me.hwnd, App.HelpFile, 3, 0)
        If Err Then
            MsgBox Err.Description
        End If
    End If

End Sub


Private Sub mnuWindowArrangeIcons_Click()
    Me.Arrange vbArrangeIcons
End Sub

Private Sub mnuWindowTileVertical_Click()
    Me.Arrange vbTileVertical
End Sub

Private Sub mnuWindowTileHorizontal_Click()
    Me.Arrange vbTileHorizontal
End Sub

Private Sub mnuWindowCascade_Click()
    Me.Arrange vbCascade
End Sub

Private Sub mnuViewStatusBar_Click()
    mnuViewStatusBar.Checked = Not mnuViewStatusBar.Checked
    sbStatusBar.Visible = mnuViewStatusBar.Checked
End Sub

Private Sub mnuFileExit_Click()
    'unload the form
    Unload Me

End Sub

Private Sub LoadMenus()
    With mtMenus.MenuTreeView
        Set .ImageList = ImageList1
        With .Nodes
            With .Add(, , "a0", "TimeBilling Shouts!", "Menus")
                .Bold = True
                .Expanded = True
            End With
            .Add "a0", 4, "WorkCode", "Work Code", "Menu"
            .Add "a0", 4, "PaymentMethod", "Payment Method", "Menu"
            .Add "a0", 4, "ExpenseCode", "Expense Code", "Menu"
            .Add "a0", 4, "Client", "Client", "Menu"
            .Add "a0", 4, "Employee", "Employee", "Menu"
            .Add "a0", 4, "ClientProject", "Project", "Menu"
            .Add "a0", 4, "TimeCard", "Time Card", "Menu"
            .Add "a0", 4, "ProjTimeCardExpense", "Project Time Card Expense", "Menu"
            .Add "a0", 4, "ProjTimeCardHour", "Project Time Card Hour", "Menu"
            .Add "a0", 4, "Payment", "Payment", "Menu"
            .Add "a0", 4, "TimeCardExpense", "Time Card Expense", "Menu"
            .Add "a0", 4, "TimeCardHour", "Time Card Hour", "Menu"
        End With
    End With
End Sub

Private Sub mtMenus_CloseMe()
    mtMenus.Visible = False
    With Me.tlBar.Buttons("Main")
        .Value = tbrUnpressed
    End With
End Sub

Private Sub mtMenus_NodeClick(ByVal Node As MSComctlLib.Node)
        On Error Resume Next
    Screen.MousePointer = vbHourglass
    If Not (Node Is Nothing) Then
        Select Case Node.Key
            Case "WorkCode"
                If Not IsLoaded(frmWorkCodeList) Then
                    frmWorkCodeList.Show
                Else
                    frmWorkCodeList.ZOrder 0
                End If
            Case "PaymentMethod"
                If Not IsLoaded(frmPaymentMethodList) Then
                    frmPaymentMethodList.Show
                Else
                    frmPaymentMethodList.ZOrder 0
                End If
            Case "ExpenseCode"
                If Not IsLoaded(frmExpenseCodeList) Then
                    frmExpenseCodeList.Show
                Else
                    frmExpenseCodeList.ZOrder 0
                End If
            Case "Client"
                If Not IsLoaded(frmClientList) Then
                    frmClientList.Show
                Else
                    frmClientList.ZOrder 0
                End If
            Case "Employee"
                If Not IsLoaded(frmEmployeeList) Then
                    frmEmployeeList.Show
                Else
                    frmEmployeeList.ZOrder 0
                End If
            Case "ClientProject"
                If Not IsLoaded(frmClientProjectList) Then
                    frmClientProjectList.Show
                Else
                    frmClientProjectList.ZOrder 0
                End If
            Case "TimeCard"
                If Not IsLoaded(frmTimeCardList) Then
                    frmTimeCardList.Show
                Else
                    frmTimeCardList.ZOrder 0
                End If
            Case "ProjTimeCardExpense"
                If Not IsLoaded(frmProjTimeCardExpenseList) Then
                    frmProjTimeCardExpenseList.Show
                Else
                    frmProjTimeCardExpenseList.ZOrder 0
                End If
            Case "ProjTimeCardHour"
                If Not IsLoaded(frmProjTimeCardHourList) Then
                    frmProjTimeCardHourList.Show
                Else
                    frmProjTimeCardHourList.ZOrder 0
                End If
            Case "Payment"
                If Not IsLoaded(frmPaymentList) Then
                    frmPaymentList.Show
                Else
                    frmPaymentList.ZOrder 0
                End If
            Case "TimeCardExpense"
                If Not IsLoaded(frmTimeCardExpenseList) Then
                    frmTimeCardExpenseList.Show
                Else
                    frmTimeCardExpenseList.ZOrder 0
                End If
            Case "TimeCardHour"
                If Not IsLoaded(frmTimeCardHourList) Then
                    frmTimeCardHourList.Show
                Else
                    frmTimeCardHourList.ZOrder 0
                End If
        End Select
    End If
    Screen.MousePointer = vbDefault
End Sub
