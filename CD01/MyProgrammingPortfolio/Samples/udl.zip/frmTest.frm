VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "comdlg32.ocx"
Begin VB.Form frmTest 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "UDL files"
   ClientHeight    =   3540
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   8355
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3540
   ScaleWidth      =   8355
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdNew 
      Caption         =   "Create New UDL File"
      Height          =   435
      Left            =   210
      TabIndex        =   2
      Top             =   1620
      Width           =   1875
   End
   Begin VB.CommandButton cmdSave 
      Caption         =   "Save to file"
      Height          =   435
      Left            =   210
      TabIndex        =   1
      Top             =   960
      Width           =   1875
   End
   Begin VB.CommandButton cmdLoad 
      Caption         =   "Load from file"
      Height          =   435
      Left            =   210
      TabIndex        =   0
      Top             =   300
      Width           =   1875
   End
   Begin MSComDlg.CommonDialog dlgCommonDialog 
      Left            =   6450
      Top             =   30
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Label Label2 
      Caption         =   "This sample application loads and saves Microsoft Universal Data Link File, pretty handy."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Left            =   2880
      TabIndex        =   4
      Top             =   750
      Width           =   4965
   End
   Begin VB.Label Label1 
      Caption         =   $"frmTest.frx":0000
      Height          =   1065
      Left            =   4380
      TabIndex        =   3
      Top             =   2370
      Width           =   3915
   End
   Begin VB.Image Image1 
      Height          =   900
      Left            =   60
      Picture         =   "frmTest.frx":00E4
      Top             =   2490
      Width           =   3915
   End
End
Attribute VB_Name = "frmTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdLoad_Click()
    Dim m_udl As New cUDL, m_FileName As String
    
    With dlgCommonDialog
        .DialogTitle = "Open"
        .CancelError = False
        .Flags = cdlOFNHideReadOnly
        .FileName = vbNullString
        'ToDo: set the flags and attributes of the common dialog control
        .Filter = "Microsoft data link files (*.udl)|*.udl"
        .ShowOpen
        m_FileName = .FileName
        If m_FileName = vbNullString Then Exit Sub
    End With
    
    With m_udl
        .LoadFromFile m_FileName
        .OpenUDL
    End With
End Sub

Private Sub cmdNew_Click()
    Dim m_udl As New cUDL, m_FileName As String
    
    With dlgCommonDialog
        .DialogTitle = "Save"
        .CancelError = False
        .Flags = cdlOFNOverwritePrompt
        'ToDo: set the flags and attributes of the common dialog control
        .Filter = "Microsoft data link files (*.udl)|*.udl"
        .FileName = vbNullString
        .ShowSave
        m_FileName = .FileName
        If m_FileName = vbNullString Then Exit Sub
    End With
    
    With m_udl
        If .CreateUDL Then .SaveToFile m_FileName
    End With
End Sub

Private Sub cmdSave_Click()
    Dim m_udl As New cUDL, m_FileName As String
    
    With dlgCommonDialog
        .DialogTitle = "Save"
        .CancelError = False
        .Flags = cdlOFNOverwritePrompt
        'ToDo: set the flags and attributes of the common dialog control
        .Filter = "Microsoft data link files (*.udl)|*.udl"
        .FileName = vbNullString
        .ShowSave
        m_FileName = .FileName
        If m_FileName = vbNullString Then Exit Sub
    End With
    
    With m_udl
        If .OpenUDL Then .SaveToFile m_FileName
    End With
End Sub
