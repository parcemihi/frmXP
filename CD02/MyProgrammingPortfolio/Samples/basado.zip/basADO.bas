Attribute VB_Name = "basADO"
Option Explicit

'Enum used for opening and closing of database objects
Enum MEPG_DB_ADO_Database_Status
    EnmIntDB_ADO_Opened_Successfully = 0
    EnmIntDB_ADO_Opened_Unsuccessfully = -1
    EnmIntDB_ADO_Path_or_Pass_Through_Blank = -2
    EnmIntDB_ADO_Name_Blank = -3
    EnmIntDB_ADO_Object_Closed_Successfully = 0
    EnmIntDB_ADO_Object_Closed_Unsuccessfully = -1
End Enum

'Enum used for recordset functions
Enum MEPG_DB_ADO_Recordset_Status
    EnmIntDB_ADO_RecordSet_Opened_UnSuccessfully = -1
    EnmIntDB_ADO_RecordSet_Opened_Successfully = 0
    EnmIntDB_ADO_RecordSet_Sql_Blank = -2
    EnmIntDB_ADO_Recordset_RecordCountZero = 0
    EnmIntDB_ADO_Recordset_ObjectIsNothing = -3
    EnmIntDB_ADO_Recordset_CannotObtainRecordCount = -5
End Enum

Enum MEPG_IntDB_ADO_RecordSetOptions
    adCmdText           ' Provider shouyld take the source as a text description of a command such as a SQL string
    adCmdTable          ' ADO should generate an SQL statement to fetch all rows from the table in Source
    adCmdTableDirect    ' Provider should return all of the rows from the table named in Source
    adStoredProc        ' Provider should treat the Source as a stored procedure
    adCmdUnknown        ' DO NOT SUE THIS -- SLOWEST of ALL Cursors.  - The command in Source is unknown.
    adCommandFile       ' Saved recordset should be restorted from the file names in the source.
    asFetchAsync        ' Source should be executed asynchronously.
End Enum

'Enum used for query execute functions
Enum MEPG_DB_ADO_QueryExecute_Status
    EnmIntDB_ADO_Query_Unsuccessful = -1
    EnmIntDB_ADO_Query_Successful = 0
End Enum
Global gDB_ADO_DatabaseConnection As ADODB.Connection
Function gfIntDB_ADO_OpenDatabase(ByRef prDB_ADOConnection As ADODB.Connection, ByVal pvStrConnectionString As String, Optional ByVal pvOptStrUserName As String = "", Optional ByVal pvOptStrPassword As String = "", Optional ByVal pvOptIntDB_ADO_Options As Integer = -1) As Integer
'----------------------------------------------------
' Purpose:
'   Open the ADO Connection to the database
'
' Parmaters:
'   1 - prDB_ADOConnection
'       The database object you wish to open
'   2 - pvStrConnectionString
'       The Pass through ODBC string
'   3 - pvOptStrUserName
'       Optional User Name
'   4 - pvOptStrPassword
'       Optional Password
'   5 - pvOptIntDB_ADO_Options
'       Optional DB Options
'
' Return Value:
'  0  if successful   (gcIntDB_ADO_Opened_Successfully)
' -1  if unsuccessful (gcIntDB_ADO_Opened_Unsuccessfully)
' -2  if unsuccessful (gcIntDB_ADO_Path_or_Pass_Through_Blank)
' -3  if unsuccessful (gcIntDB_ADO_Name_Blank)
' -4  if unsuccessful (gcIntDB_ADO_IndicatorInvalid)
' err if unsuccessful (VB error handler code)
'
'Notes:
' This routine check to see if the database is nothing
' before it attempts to open the database
'
' The database is declared global.
'
'Modification:
'970430  SBI0
'        Added code to correct trailing backslash error
'970425  SBI0
'        Added Parameter to determine query options
'        Added code to close the recordset object if recordset was unsuccessful
'970423  SBI
'        Added check for trailing backslash
'        Added parameter to determine is you want to
'        open the database using access method, or
'        remote server method, such as SQL Server
'
'970225  SBI0
'        New
'-----------------------------------------------------

    Dim lLogContinue        As Integer
    Dim lIntStatusOfOpen    As Integer
    Dim lIntStatusOfClose   As Integer

    Const lcStrBackSlash = "\"
    Const lcIntNoErrors = 0

    lIntStatusOfOpen = EnmIntDB_ADO_Object_Closed_Unsuccessfully
    
    'recreate the database connection object
    On Error Resume Next
    Set prDB_ADOConnection = New ADODB.Connection
    prDB_ADOConnection = ""
    If Err = lcIntNoErrors Then
        lLogContinue = True
    Else
        lIntStatusOfOpen = Err
    End If
    On Error GoTo 0

    If lLogContinue = True Then

        On Error Resume Next
        'Open the database connection
        prDB_ADOConnection.Open pvStrConnectionString, pvOptStrUserName, pvOptStrPassword, pvOptIntDB_ADO_Options
          DoEvents
        If Err = lcIntNoErrors And prDB_ADOConnection.State = adStateOpen Then
            'return successfull
            lIntStatusOfOpen = EnmIntDB_ADO_Opened_Successfully
        Else
            lIntStatusOfOpen = Err
        End If
        On Error GoTo 0
    End If
    
    gfIntDB_ADO_OpenDatabase = lIntStatusOfOpen
    
End Function
Function gfIntDB_ADO_CloseObject(ByRef prDB_ADO_DatabaseObject As Object) As Integer
'----------------------------------------------------
' Purpose:
'   Closes any DB object
'
' Parmaters:
'   1 - prDB_ADO_DatabaseObject
'       The database object you wish to open
'
' Return Value:
'   0  if successful   (gcIntDB_ADO_Object_Closed_Successfully)
'   -1  if unsuccessful (gcIntDB_ADO_Object_Closed_Unsuccessfully)
'   err if unsuccessful (VB error handler code)
'
' Notes:
'   This routine check to see if the object is nothing
'   before it attempts to close the object
'
' Modification:
'   990204  SBI0
'           Changed to work with ADO
'   970225  SBI0
'           New
'-----------------------------------------------------

    Dim lIntStatusOfObjectClose As Integer
    Const lcIntNoErrors = 0

    On Error Resume Next
    lIntStatusOfObjectClose = EnmIntDB_ADO_Object_Closed_Unsuccessfully
    If Not (prDB_ADO_DatabaseObject Is Nothing) Then
        prDB_ADO_DatabaseObject.Close
        Set prDB_ADO_DatabaseObject = Nothing
    End If

    If Err = lcIntNoErrors Then
        lIntStatusOfObjectClose = EnmIntDB_ADO_Object_Closed_Successfully
    Else
        lIntStatusOfObjectClose = Err
    End If
    On Error GoTo 0

    gfIntDB_ADO_CloseObject = lIntStatusOfObjectClose

End Function
Function gfIntDB_ADO_OpenRecordSet(ByRef prDB_ADOConnection As ADODB.Connection, ByRef prDB_ADORecordset As ADODB.Recordset, ByVal pvStrRecordSource As String, Optional ByVal pvOptEnmCursorTypeEnum As CursorTypeEnum = adOpenStatic, Optional ByVal pvOptEnmLockTypeEnum As LockTypeEnum = adLockUnspecified, Optional ByVal pvOptEnmDB_ADO_RecordSetOptions As MEPG_IntDB_ADO_RecordSetOptions) As Integer
'----------------------------------------------------
' Purpose:
'   To Run the open recordset function and return a record
'   colletion
'
' Parmaters:
'   1 - prDB_ADOConnection
'       Database object
'   2 - prDB_ADORecordset
'       The collection of the record set that needs to be returned
'   3 - pvStrRecordSource
'       This is the SQL string
'   4 - pvOptenmCursorTypeEnum
'       Specifies the type of recordset to open
'       adOpenDynamic = 2
'       adOpenForwardOnly = 0
'       adOpenKeyset = 1
'       adOpenStatic = 3  'Routine Default
'       adOpenUnspecified = -1  'VB Default
'   5 - pvOptEnmLockTypeEnum
'       adLockBatchOptimistic = 4
'       adLockOptimistic = 3
'       adLockPessimistic = 2
'       adLockReadOnly = 1
'       adLockUnspecified = -1 'Routine and VB Default
'   6 - pvOptEnmDB_ADO_RecordSetOptions
'       adCmdText           - Provider shouyld take the source as a text description of a command such as a SQL string
'       adCmdTable          - ADO should generate an SQL statement to fetch all rows from the table in Source
'       adCmdTableDirect    - Provider should return all of the rows from the table named in Source
'       adStoredProc        - Provider should treat the Source as a stored procedure
'       AdCmdUnknown        - DO NOT SUE THIS -- SLOWEST of ALL Cursors.  - The command in Source is unknown.
'       adCommandFile       - Saved recordset should be restorted from the file names in the source.
'       asFetchAsync        - Source should be executed asynchronously.
'
' Return Value:
'   0  if successful   (gcIntDB_RecordSet_Opened_Successfully)
'   -1  if unsuccessful (gcIntDB_RecordSet_Opened_UnSuccessfully)
'   -2  if unsuccessful (gcIntDB_RecordSet_Sql_Blank)
'   err if unsuccessful (VB error handler code)
'
' Notes:
'   This routine will run openrecordset queries.
'   VERY IMPORTANT.  IN ORDER TO USE THE RECORDCOUNT PROPERTY THE RECORD SET
'   MUST BE OPEN WITH THE "adOpenStatic" option
'
' Modification:
'   990216  SBI0
'           Changed from .Execute, to .Open, and added the correct parameters, such as
'           CursorType, Lock Type, and Enum Options.
'   990204  SBI0
'           Changed to work with ADO
'   970420  SBI0
'           Added Parameter to determine query options
'           Added code to close the recordset object if recordset was unsuccessful
'   970225  SBI0
'           New
'-----------------------------------------------------

    Dim lLogContinue                As Integer
    Dim lIntStatusOfRecordSetOpen   As Integer
    Dim lIntStatusOfClose           As Integer
    Const lcIntNoErrors = 0

    lIntStatusOfRecordSetOpen = EnmIntDB_ADO_RecordSet_Opened_UnSuccessfully

    'close the open database object
    On Error Resume Next
    Set prDB_ADORecordset = New ADODB.Recordset
    If Err = lcIntNoErrors Then
        lLogContinue = True
    Else
        lIntStatusOfRecordSetOpen = Err
    End If
    On Error GoTo 0


    If lLogContinue = True Then
        If pvStrRecordSource = "" Then
            lLogContinue = False
            lIntStatusOfRecordSetOpen = EnmIntDB_ADO_RecordSet_Sql_Blank
        End If
    End If

    If lLogContinue = True Then

        On Error Resume Next
        DoEvents
        prDB_ADORecordset.Open pvStrRecordSource, prDB_ADOConnection, pvOptEnmCursorTypeEnum, pvOptEnmLockTypeEnum, pvOptEnmDB_ADO_RecordSetOptions
        DoEvents

        If Err = lcIntNoErrors And prDB_ADORecordset.State = adStateOpen Then
           lIntStatusOfRecordSetOpen = EnmIntDB_ADO_RecordSet_Opened_Successfully
        Else
            lIntStatusOfRecordSetOpen = Err
'           if the database did not open succesfully
'            make sure recordset object is set to nothing
            lIntStatusOfClose = gfIntDB_ADO_CloseObject(prDB_ADORecordset)
        End If
        On Error GoTo 0

    End If

    gfIntDB_ADO_OpenRecordSet = lIntStatusOfRecordSetOpen

End Function
Function gfIntDB_ADO_ExecuteSQL(ByRef prDB_ADOConnection As ADODB.Connection, ByVal pvStrRecordSource As String) As Integer
'----------------------------------------------------
' Purpose:
'   To execute update, delete and other similar queries
'
'Parmaters:
'   1 - prDB_ADOConnection
'       Database object
'   2 - pvStrRecordSource
'       This is the SQL string
'
' Return Value:
'   0  if successful   (gcIntDB_ADO_Query_Successful)
'   -1  if unsuccessful (gcIntDB_ADO_Query_Unsuccessful)
'   err if unsuccessful (VB error handler code)
'
'
' Notes:
'   This routine will work for both Access and SQLserver
'
'   This routine will run execute queries.
'
'Modification:
'   990204  SBI0
'           Changed to work with ADO
'   970225  SBI0
'           New
'-----------------------------------------------------


    Dim lIntStatusOfQuery As Integer
    Const lcIntNoErrors = 0

    lIntStatusOfQuery = EnmIntDB_ADO_Query_Unsuccessful

    On Error Resume Next
    DoEvents
    prDB_ADOConnection.Execute pvStrRecordSource
    DoEvents

    If Err = lcIntNoErrors Then
        lIntStatusOfQuery = EnmIntDB_ADO_Query_Successful
    Else
        lIntStatusOfQuery = Err
    End If
    On Error GoTo 0

    gfIntDB_ADO_ExecuteSQL = lIntStatusOfQuery

End Function
Function gfLngDB_ADO_GetRecordCountOfRecordset(ByRef prDB_ADORecordset As ADODB.Recordset) As Long
'----------------------------------------------------
' Purpose:
'   To return the record of the recordset object
'
' Parmaters:
'   1 - prDB_ADORecordset
'       Recordset to check
'
' Return Value:
'   #  - recordcount value
'   0  - gcIntDB_ADO_Recordset_RecordCountZero
'   -3  - gcIntDB_ADO_Recordset_ObjectIsNothing
'
' Notes:
'   This routine must have error checking including
'   were you attempt to movelast, or movefirst in the
'   recordset.  In some cases the recordset may not allow
'   such a behavior causing an error.  In that case the function
'   will return the current count you are on in the recordset.
'
'   This routine will work for both Access and SQLserver
'
'   This routine will return 0 if no recordcount is found,
'   and gcIntDB_ADO_Recordset_ObjectIsNothing is the recordset
'   is not set
'
'Modification:
' 990204  SBI0
'         Changed to work with ADO
' 970430  SBI0
'         Corrected a possible error when movinglast, or
'         moving first in a recordset.  Some recordset that
'         you can create do not support this behavior.
' 970425  SBI0
'         New
'-----------------------------------------------------

    Dim lLogContinue                As Integer
    Dim lLngStatusOfRecordCount     As Long

    lLogContinue = True
    lLngStatusOfRecordCount = EnmIntDB_ADO_Recordset_RecordCountZero


    If (prDB_ADORecordset Is Nothing) Then
        lLngStatusOfRecordCount = EnmIntDB_ADO_Recordset_ObjectIsNothing
        lLogContinue = False
    End If

    If lLogContinue = True Then
        If (prDB_ADORecordset.RecordCount = -1) Then
            lLngStatusOfRecordCount = EnmIntDB_ADO_Recordset_CannotObtainRecordCount
            lLogContinue = False
        End If
    End If

    If lLogContinue = True Then
        If prDB_ADORecordset.RecordCount = 0 Then
            lLogContinue = False
            lLngStatusOfRecordCount = EnmIntDB_ADO_Recordset_RecordCountZero
        Else
'             Note: You need error checking including
'             were you attempt to movelast, or movefirst in the
'             recordset because this may cause an error in certain
'             recordsets that do not allow this behavior.
'             In that case the function will return the
'             current count you are on in the recordset.
            prDB_ADORecordset.MoveLast
            lLngStatusOfRecordCount = prDB_ADORecordset.RecordCount
            prDB_ADORecordset.MoveFirst
        End If
    End If

    gfLngDB_ADO_GetRecordCountOfRecordset = lLngStatusOfRecordCount

End Function

