VERSION 5.00
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomct2.ocx"
Object = "{C932BA88-4374-101B-A56C-00AA003668DC}#1.1#0"; "MSMASK32.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "tabctl32.ocx"
Begin VB.Form frmClient 
   Caption         =   "Client"
   ClientHeight    =   5490
   ClientLeft      =   1110
   ClientTop       =   345
   ClientWidth     =   7470
   Icon            =   "frmClient.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Client"
   MDIChild        =   -1  'True
   ScaleHeight     =   5490
   ScaleWidth      =   7470
   Begin VB.Label lblLabels 
      Caption         =   "Address:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   0
      Left            =   150
      TabIndex        =   2
      Top             =   510
      Width           =   1815
   End
   Begin VB.TextBox Address
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   1
      Top             =   510
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "City:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   1
      Left            =   150
      TabIndex        =   4
      Top             =   835
      Width           =   1815
   End
   Begin VB.TextBox City
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   3
      Top             =   835
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Client ID(Auto):"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   2
      Left            =   150
      TabIndex        =   6
      Top             =   1160
      Width           =   1815
   End
   Begin VB.TextBox ClientID
      BackColor       =   &H8000000F&
      Enabled         =   0   'False 
      Alignment       =   1 
      Height          =   315
      Left            =   2070
      TabIndex        =   5
      Top             =   1160
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Client Name:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   3
      Left            =   150
      TabIndex        =   8
      Top             =   1485
      Width           =   1815
   End
   Begin VB.TextBox CompanyName
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   7
      Top             =   1485
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Contact First Name:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   4
      Left            =   150
      TabIndex        =   10
      Top             =   1810
      Width           =   1815
   End
   Begin VB.TextBox ContactFirstName
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   9
      Top             =   1810
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Contact Last Name:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   5
      Left            =   150
      TabIndex        =   12
      Top             =   2135
      Width           =   1815
   End
   Begin VB.TextBox ContactLastName
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   11
      Top             =   2135
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Contact Title:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   6
      Left            =   150
      TabIndex        =   14
      Top             =   2460
      Width           =   1815
   End
   Begin VB.TextBox ContactTitle
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   13
      Top             =   2460
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Country:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   7
      Left            =   150
      TabIndex        =   16
      Top             =   2785
      Width           =   1815
   End
   Begin VB.TextBox Country
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   15
      Top             =   2785
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Fax:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   8
      Left            =   150
      TabIndex        =   18
      Top             =   3110
      Width           =   1815
   End   
   Begin MSMask.MaskEdBox FaxNumber 
      Height          =   315
      Left            =   2070
      TabIndex        =   17
      Top             =   3110
      Width           =   3375
      _ExtentX        =   2990
      _ExtentY        =   503
      _Version        =   393216
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      PromptChar      =   "_"
   End 
   Begin VB.Label lblLabels 
      Caption         =   "Notes:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   9
      Left            =   150
      TabIndex        =   20
      Top             =   3435
      Width           =   1815
   End
   Begin VB.TextBox Notes
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   19
      Top             =   3435
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Phone:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   10
      Left            =   150
      TabIndex        =   22
      Top             =   3760
      Width           =   1815
   End
   Begin VB.TextBox PhoneNumber
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   21
      Top             =   3760
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Postal Code:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   11
      Left            =   150
      TabIndex        =   24
      Top             =   4085
      Width           =   1815
   End   
   Begin MSMask.MaskEdBox PostalCode 
      Height          =   315
      Left            =   2070
      TabIndex        =   23
      Top             =   4085
      Width           =   3375
      _ExtentX        =   2990
      _ExtentY        =   503
      _Version        =   393216
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      PromptChar      =   "_"
   End 
   Begin VB.Label lblLabels 
      Caption         =   "State:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   12
      Left            =   150
      TabIndex        =   26
      Top             =   4410
      Width           =   1815
   End
   Begin VB.TextBox StateOrProvince
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   25
      Top             =   4410
      Width           =   3375
   End  
   Begin TabDlg.SSTab tabListview 
      Height          =   2895
      Left            =   0
      TabIndex        =   0
      Top             =   4735
      Width           =   7395
      _ExtentX        =   13044
      _ExtentY        =   5106
      _Version        =   393216
      TabOrientation  =   1
      Tabs            =   1
      TabHeight       =   520 
      TabCaption(0)   =   "Projects"
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "DataEditGrid1(0)"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).ControlCount=   1       
      Begin TimeBillingUI.DataEditGrid DataEditGrid1 
         Height          =   2145
         Index           =   0
         Left            =   150
         TabIndex        =   1
         Top             =   180
         Width           =   6900
         _extentx        =   12171
         _extenty        =   3784
         AllowAddNew     =   -1
         Grouped         =   0   'False
      End
   End
   Begin TimeBillingUI.CaptionBar CaptionBar1 
      Align           =   1  'Align Top
      Height          =   435
      Left            =   0
      TabIndex        =   5
      Top             =   0
      Width           =   7470
      _extentx        =   13176
      _extenty        =   767
      border          =   4
      forecolor       =   -2147483643
      Caption         =   "ok i am here"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   10.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty SubCaptionFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End   
End
Attribute VB_Name = "frmClient"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Implements iForm
Private Const mcstrMod$ = "frmClient"
Private m_Client As COMEXDataSourceSingle, m_Store As COMEXDataSourceSingle
Private m_flgLoading As Boolean
Private m_EnableAttr As ToolBarItems
Private m_Guid As String

Public Sub Component(vClient As COMEXDataSourceSingle)
    Set m_Client = vClient
    Set m_Store = m_Client.CopyMe
    LoadRecords
End Sub

Private Sub EnableToolbar(ByVal Dirty As Boolean)
    On Error Resume Next
    If Not Dirty Then
        If m_EnableAttr And tbSave Then m_EnableAttr = m_EnableAttr Xor tbSave
        If m_EnableAttr And tbCancel Then m_EnableAttr = m_EnableAttr Xor tbCancel
        If Not (m_EnableAttr And tbRefresh) Then m_EnableAttr = m_EnableAttr Or tbRefresh
    Else
        If Not (m_EnableAttr And tbSave) Then m_EnableAttr = m_EnableAttr Or tbSave
        If Not (m_EnableAttr And tbCancel) Then m_EnableAttr = m_EnableAttr Or tbCancel
        If m_EnableAttr And tbRefresh Then m_EnableAttr = m_EnableAttr Xor tbRefresh
    End If
    m_Toolbar.RefreshEnabledState
End Sub

Private Sub LoadRecords()
    On Error GoTo Err_LoadRecords
    
    Dim ctl As Control, i As Long 
    
    m_flgLoading = True
    
    Dim aClient As Client
    Set aClient = m_Client
    
    
    Dim vClientProjects As COMEXDataSource
    Set vClientProjects = aClient.ClientProjects
    
    
    With m_Client
        For i = 1 To .GetFieldCount
            On Error Resume Next
            Set ctl = Controls(.GetFieldName(i))
            If Err = 0 Then
                Select Case TypeName(ctl)
                    Case "Label"
                    Case "TextBox", "ComboBox", "MaskEdBox"
                        ctl = .GetData(i)
                    Case "CheckBox"
                    	ctl.Value = abs(.GetData(i))
                    Case "DTPicker"
                        ctl.Value = .GetData(i)
                End Select
            End If
        Next
    End With
    
    Set Me.DataEditGrid1(0).DataSource = vClientProjects
    m_EnableAttr = iForm_Attributes
    EnableToolbar False
    m_flgLoading = False
Done_LoadRecords:
    Exit Sub
Err_LoadRecords:
    ErrorMsg Err.Number, Err.Description, "LoadRecords", mcstrMod
    Resume Done_LoadRecords
End Sub

 
Private Sub Address_Change()
    On Error GoTo Err_Address_Change
    If m_flgLoading Then Exit Sub
    m_Client.SetDatabyname Address.Name, Address
    EnableToolbar True
    Exit Sub
Err_Address_Change:
    With Address
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Client.GetDataByName(Address.Name)
    End With
End Sub
Private Sub Address_LostFocus()
    On Error Resume Next
    Address = m_Client.GetDataByName(Address.Name)
End Sub
 
Private Sub City_Change()
    On Error GoTo Err_City_Change
    If m_flgLoading Then Exit Sub
    m_Client.SetDatabyname City.Name, City
    EnableToolbar True
    Exit Sub
Err_City_Change:
    With City
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Client.GetDataByName(City.Name)
    End With
End Sub
Private Sub City_LostFocus()
    On Error Resume Next
    City = m_Client.GetDataByName(City.Name)
End Sub
 
Private Sub ClientID_Change()
    On Error GoTo Err_ClientID_Change
    If m_flgLoading Then Exit Sub
    m_Client.SetDatabyname ClientID.Name, ClientID
    EnableToolbar True
    Exit Sub
Err_ClientID_Change:
    With ClientID
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Client.GetDataByName(ClientID.Name)
    End With
End Sub
Private Sub ClientID_LostFocus()
    On Error Resume Next
    ClientID = m_Client.GetDataByName(ClientID.Name)
End Sub
 
Private Sub CompanyName_Change()
    On Error GoTo Err_CompanyName_Change
    If m_flgLoading Then Exit Sub
    m_Client.SetDatabyname CompanyName.Name, CompanyName
    EnableToolbar True
    Exit Sub
Err_CompanyName_Change:
    With CompanyName
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Client.GetDataByName(CompanyName.Name)
    End With
End Sub
Private Sub CompanyName_LostFocus()
    On Error Resume Next
    CompanyName = m_Client.GetDataByName(CompanyName.Name)
End Sub
 
Private Sub ContactFirstName_Change()
    On Error GoTo Err_ContactFirstName_Change
    If m_flgLoading Then Exit Sub
    m_Client.SetDatabyname ContactFirstName.Name, ContactFirstName
    EnableToolbar True
    Exit Sub
Err_ContactFirstName_Change:
    With ContactFirstName
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Client.GetDataByName(ContactFirstName.Name)
    End With
End Sub
Private Sub ContactFirstName_LostFocus()
    On Error Resume Next
    ContactFirstName = m_Client.GetDataByName(ContactFirstName.Name)
End Sub
 
Private Sub ContactLastName_Change()
    On Error GoTo Err_ContactLastName_Change
    If m_flgLoading Then Exit Sub
    m_Client.SetDatabyname ContactLastName.Name, ContactLastName
    EnableToolbar True
    Exit Sub
Err_ContactLastName_Change:
    With ContactLastName
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Client.GetDataByName(ContactLastName.Name)
    End With
End Sub
Private Sub ContactLastName_LostFocus()
    On Error Resume Next
    ContactLastName = m_Client.GetDataByName(ContactLastName.Name)
End Sub
 
Private Sub ContactTitle_Change()
    On Error GoTo Err_ContactTitle_Change
    If m_flgLoading Then Exit Sub
    m_Client.SetDatabyname ContactTitle.Name, ContactTitle
    EnableToolbar True
    Exit Sub
Err_ContactTitle_Change:
    With ContactTitle
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Client.GetDataByName(ContactTitle.Name)
    End With
End Sub
Private Sub ContactTitle_LostFocus()
    On Error Resume Next
    ContactTitle = m_Client.GetDataByName(ContactTitle.Name)
End Sub
 
Private Sub Country_Change()
    On Error GoTo Err_Country_Change
    If m_flgLoading Then Exit Sub
    m_Client.SetDatabyname Country.Name, Country
    EnableToolbar True
    Exit Sub
Err_Country_Change:
    With Country
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Client.GetDataByName(Country.Name)
    End With
End Sub
Private Sub Country_LostFocus()
    On Error Resume Next
    Country = m_Client.GetDataByName(Country.Name)
End Sub

Private Sub FaxNumber_Change()
    On Error GoTo Err_FaxNumber_Change
    If m_flgLoading Then Exit Sub
    m_Client.SetDatabyname FaxNumber.Name, FaxNumber
    EnableToolbar True
    Exit Sub
Err_FaxNumber_Change:
    FaxNumber = m_Client.GetDatabyname(FaxNumber.Name)
End Sub 
Private Sub FaxNumber_LostFocus()
    On Error Resume Next
    FaxNumber = m_Client.GetDataByName(FaxNumber.Name)
End Sub
 
Private Sub Notes_Change()
    On Error GoTo Err_Notes_Change
    If m_flgLoading Then Exit Sub
    m_Client.SetDatabyname Notes.Name, Notes
    EnableToolbar True
    Exit Sub
Err_Notes_Change:
    With Notes
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Client.GetDataByName(Notes.Name)
    End With
End Sub
Private Sub Notes_LostFocus()
    On Error Resume Next
    Notes = m_Client.GetDataByName(Notes.Name)
End Sub
 
Private Sub PhoneNumber_Change()
    On Error GoTo Err_PhoneNumber_Change
    If m_flgLoading Then Exit Sub
    m_Client.SetDatabyname PhoneNumber.Name, PhoneNumber
    EnableToolbar True
    Exit Sub
Err_PhoneNumber_Change:
    With PhoneNumber
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Client.GetDataByName(PhoneNumber.Name)
    End With
End Sub
Private Sub PhoneNumber_LostFocus()
    On Error Resume Next
    PhoneNumber = m_Client.GetDataByName(PhoneNumber.Name)
End Sub

Private Sub PostalCode_Change()
    On Error GoTo Err_PostalCode_Change
    If m_flgLoading Then Exit Sub
    m_Client.SetDatabyname PostalCode.Name, PostalCode
    EnableToolbar True
    Exit Sub
Err_PostalCode_Change:
    PostalCode = m_Client.GetDatabyname(PostalCode.Name)
End Sub 
Private Sub PostalCode_LostFocus()
    On Error Resume Next
    PostalCode = m_Client.GetDataByName(PostalCode.Name)
End Sub
 
Private Sub StateOrProvince_Change()
    On Error GoTo Err_StateOrProvince_Change
    If m_flgLoading Then Exit Sub
    m_Client.SetDatabyname StateOrProvince.Name, StateOrProvince
    EnableToolbar True
    Exit Sub
Err_StateOrProvince_Change:
    With StateOrProvince
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_Client.GetDataByName(StateOrProvince.Name)
    End With
End Sub
Private Sub StateOrProvince_LostFocus()
    On Error Resume Next
    StateOrProvince = m_Client.GetDataByName(StateOrProvince.Name)
End Sub



Private Sub tabListview_Click(PreviousTab As Integer)
	
  Me.DataEditGrid1(0).Visible =(tabListview.tab = 0)
  Me.Refresh
End Sub

Private Sub DataEditGrid1_Dirty(Index As Integer)
    EnableToolbar True
End Sub

Private Sub DataEditGrid1_FetchColumnSetup(Index As Integer, ColName As String, ControlType As FieldControlType, ComboMaskList As String, Alignment As FieldControlAlign, Hidden As Boolean, AutoNumber As Boolean)
    Select Case Index    
        Case 0
            Select Case ColName
                Case "ClientID"
                    Hidden = True
            End Select
            Dim vClientProject As New ClientProject
            Select Case ColName 
                Case "ClientID"
                    ColName = "Client ID"
                    AutoNumber = False
                    Alignment = 0
                    ControlType = fcComboBx
                    ComboMaskList = vClientProject.GetClientsList
                Case "EmployeeID"
                    ColName = "Employee"
                    AutoNumber = False
                    Alignment = 0
                    ControlType = fcComboBx
                    ComboMaskList = vClientProject.GetEmployeesList
                Case "ProjectDescription"
                    ColName = "Project Description"
                    AutoNumber = False
                    Alignment = 0			
                Case "ProjectEndDate"
                    ColName = "Project End Date"
                    AutoNumber = False
                    Alignment = 1
                    ControlType = fcDateTimePick
                Case "ProjectID"
                    ColName = "Project ID"
                    AutoNumber = True
                    Alignment = 2
                Case "ProjectName"
                    ColName = "Project Name"
                    AutoNumber = False
                    Alignment = 0
                Case "ProjectTotalBillingEstimate"
                    ColName = "Total Billing Estimate"
                    AutoNumber = False
                    Alignment = 2
                Case "PurchaseOrderNumber"
                    ColName = "Purchase Order Number"
                    AutoNumber = False
                    Alignment = 0			
                Case "ProjectBeginDate"
                    ColName = "Project Begin Date"
                    AutoNumber = False
                    Alignment = 1
                    ControlType = fcDateTimePick
            End Select
    End Select	
End Sub

Private Sub Form_Activate()
    m_Toolbar.Activate m_Guid
End Sub

Private Sub Form_Load()
	Dim vClient As New Client, strCombo As String
    m_Guid = GUID
    m_Toolbar.Attach Me, m_Guid

    tabListview_Click 0 
	ThinBorder DataEditGrid1(0).hwnd, False 
    CaptionBar1.Caption = Caption
    Set CaptionBar1.Picture = Me.Icon

	FaxNumber.mask = "(###)###-####"

	PostalCode.mask = "#####"
    
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    If m_EnableAttr And tbSave Then
        Select Case MsgBox("Record has been changed. Do you want To save it?" _
            , vbYesNoCancel + vbQuestion)
            Case vbYes
                m_Client.Save
            Case vbNo
            Case vbCancel
                Cancel = True
        End Select
    End If
End Sub

Private Sub Form_Resize()    
	On Error Resume Next	
	If Me.WindowState <> vbMinimized Then
	    With CaptionBar1
	        .Move 0, .Top, Me.ScaleWidth, .Height
	    End With 
	    With tabListview
	        .Left = 0
	        .Top = (StateOrProvince.Top + StateOrProvince.Height + 100)
	        .Height = Me.ScaleHeight - .Top
	        .Width = Me.ScaleWidth
	        DataEditGrid1(0).Move 100, 100, .Width - 200, .Height - 450
	    End With          
	End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    m_Toolbar.Detach m_Guid
End Sub

Private Sub LoadFormView()
    On Error GoTo Err_LoadFormView
    Dim vItem As Object, frmX As Object , aClient As Client
    
    Set aClient = m_Client
    Select Case tabListview.Tab
       	Case 0      
       		Dim vClientProject As ClientProject
       		Set vItem = New ClientProject
       		Set frmX = New frmClientProject                                            
       		Set vClientProject = aClient.ClientProjects(DataEditGrid1(tabListview.Tab).CurrentRecord)
       		vItem.Load vClientProject.ProjectID, True    
    End Select    
    frmX.Component vItem
    frmX.Show
Done_LoadFormView:
    Exit Sub
Err_LoadFormView:
    If err <> 91 Then ErrorMsg Err.Number, Err.Description, "LoadFormView", mcstrMod
    Resume Done_LoadFormView
End Sub

Private Sub iForm_MainMenu()
    'n/a
End Sub

Private Property Get iForm_Attributes() As ToolBarItems
    iForm_Attributes = tbCancel + tbCloseMe + tbRefresh + tbSave   + tbDeleteRow + tbShowFormView
End Property

Private Sub iForm_Cancel()
    Set m_Client = m_Store.CopyMe
    LoadRecords
End Sub

Private Sub iForm_CloseMe()
    Unload Me
End Sub

Private Sub iForm_delete()
    'n/a
End Sub

Private Property Get iForm_EnableAttributes() As ToolBarItems
    iForm_EnableAttributes = m_EnableAttr
End Property

Private Sub iForm_Find(ByVal Key As String)
    'n/a
End Sub

Private Sub iForm_Refresh()
    Dim aClient As Client
    Set aClient = m_Client
    aClient.Load aClient.ClientID, True
    Set m_Client = aClient
    LoadRecords
End Sub

Private Function iForm_Save() As Boolean
    DataEditGrid1(tabListview.Tab).Update
    If m_Client.Save Then 
    	Set m_Store = m_Client.CopyMe
    	iForm_Refresh
    End If
End Function

Private Sub iForm_AddNew()
    'n/a
End Sub

Private Sub iForm_ShowFormView()   
	LoadFormView
End Sub

Private Property Get iForm_FindSubTools() As cFindSubTools
    'n/a
End Property

Private Sub iForm_HelpAbout()
    'n/a
End Sub

Private Function iForm_OpenDB() As Boolean
    'n/a
End Function

Private Sub iForm_DeleteRow()
    DataEditGrid1(tabListview.Tab).delete    
End Sub

Private Sub iForm_PrintOut()
    'n/a
End Sub