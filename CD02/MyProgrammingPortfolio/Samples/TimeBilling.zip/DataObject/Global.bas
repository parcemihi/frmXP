Attribute VB_Name = "Globals"
Option Explicit
Public Conn As New ADODB.Connection
Public ErrNum As long, ErrMsg As String, mvarIsConnected As Boolean

Public Function ErrHandler(ByVal ErrorNumber As Long, ByVal ErrorMessage As String, ByVal ModuleName As string, byval FunctionName As string)
  'Err.Raise ErrorNumber, app.EXEName & "." & ModuleName & "." & FunctionName, ErrorMessage
'optionally you can display an error msgbox 
  Msgbox "Error Number:" & ErrorNumber & vbCrLf & _
    "Error Message:" & ErrorMessage & vbCrLf & _
    "Module:" & ModuleName & vbCrLf & _
    "Function:" & FunctionName , vbCritical
End Function   

Public Function InvalidHandler(ByVal strBrokenRules As string)
  'Err.Raise 445, app.EXEName, strBrokenRules 
'optionally you can display an error msgbox 
  Msgbox "The following fields must be filled With: " & strBrokenRules , vbCritical
End Function