Attribute VB_Name = "modGen"
Option Explicit
Public glngTmp As Long
Public gdbCon As Connection 'Store Connection Object
Public gblnChkUnique As Boolean 'Boolean Variable to Check Unique Constraints
Public gstrConn As String 'Connection String
Public gstrSQL As String 'store Temporary SQL
Public Const gstrAddEditTB = "0000000000000100" 'Enable or Disable ToolBar Buttons in Add or Edit Mode
Public Const gstrSaveClTB = "1101110111100001" 'Enable or Disable ToolBar Buttons in Save or Cancel Mode

Public Function Fun_Connect()
'Procedure to Connect Valid DataSource
On Error GoTo LocalErr
    Screen.MousePointer = vbHourglass
    gstrConn = "PROVIDER=Microsoft.Jet.OLEDB.3.51;Data Source=" & App.Path & "\Sample.mdb;"
    Set gdbCon = New Connection
    gdbCon.CursorLocation = adUseClient
    gdbCon.ConnectionTimeout = 120
    gdbCon.Open gstrConn
    Fun_Connect = 0
    Screen.MousePointer = vbDefault
    Exit Function
LocalErr:
    Screen.MousePointer = vbDefault
    MsgBox Err.Description
End Function

Public Function Fun_GetValue(fv_sql As String)
'Pass SQL and get Value
'Example "Select count(*) from area"
On Error GoTo LocalErr
    Screen.MousePointer = vbHourglass
    Dim rsTmp As New Recordset
    Set rsTmp = Fun_GetRecordset(fv_sql)
    If rsTmp.EOF Then Fun_GetValue = "": Exit Function
    Fun_GetValue = IIf(IsNull(rsTmp(0)), "", rsTmp(0))
    Screen.MousePointer = vbDefault
    Set rsTmp = Nothing
Exit Function
LocalErr:
    Screen.MousePointer = vbDefault
    Set rsTmp = Nothing
    MsgBox Err.Description
End Function

Public Function Fun_GetRecordset(fv_sql) As Recordset
'Pass Valid SQL and Get Recordset
On Error GoTo LocalErr
    Screen.MousePointer = vbHourglass
    Dim rsTmp As Recordset
    Set rsTmp = New Recordset
    With rsTmp
        .CursorLocation = adUseClient
        .CursorType = adOpenStatic
        .LockType = adLockReadOnly
        .ActiveConnection = gstrConn
        .Source = fv_sql
        .Open
    End With
    Set Fun_GetRecordset = rsTmp
    Set rsTmp = Nothing
    Screen.MousePointer = vbDefault
    Exit Function
LocalErr:
    MsgBox Err.Description
    Screen.MousePointer = vbDefault
    Set rsTmp = Nothing
End Function

Public Function TBEnable(frmtemp As Object, strList As String)
    ' //PARAMETERS - 1) FORM NAME
    '                2) ButtonList
    '
    ' enable buttons
    '
    On Error GoTo LocalErr
    '
    Dim intLoop As Integer
    '
    strList = Trim(strList)
    '
    For intLoop = 1 To Len(strList)
        If Mid(strList, intLoop, 1) = "1" Then
            frmtemp.tlbToolBar.Buttons(intLoop).Enabled = True
        Else
            frmtemp.tlbToolBar.Buttons(intLoop).Enabled = False
        End If
    Next
    '
    TBEnable = 0
    Exit Function
    '
LocalErr:
    TBEnable = Err.Number
    '
End Function

Public Sub Fun_Cancel()
'Procedure to Cancel Recordset Operation
On Error GoTo LocalErr
    Screen.MousePointer = vbHourglass
    frmmdi.ActiveForm.DataAny "CANCEL"
    TBEnable frmmdi, gstrSaveClTB
    Screen.MousePointer = vbDefault
    Exit Sub
LocalErr:
    Screen.MousePointer = vbDefault
    MsgBox Err.Description
End Sub

Sub MsgBar(rsMsg As String, rPauseFlag As Integer)
    If Len(rsMsg) = 0 Then
        Screen.MousePointer = vbDefault
        frmmdi.stsStatusBar.Panels(1).Text = "Ready"
    Else
        If rPauseFlag Then
            frmmdi.stsStatusBar.Panels(1).Text = rsMsg & ", Please Wait..."
        Else
            frmmdi.stsStatusBar.Panels(1).Text = rsMsg
        End If
    End If
    frmmdi.stsStatusBar.Refresh
End Sub

Public Sub Fun_Update()
'Procedure to Save Record
On Error GoTo LocalErr
    Screen.MousePointer = vbHourglass
    frmmdi.ActiveForm.DataAny "SAVE"
    TBEnable frmmdi, gstrSaveClTB
    Screen.MousePointer = vbDefault
Exit Sub
LocalErr:
    Screen.MousePointer = vbDefault
    MsgBox Err.Description
End Sub
