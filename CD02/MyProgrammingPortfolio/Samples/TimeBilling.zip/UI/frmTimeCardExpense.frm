VERSION 5.00
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomct2.ocx"
Object = "{C932BA88-4374-101B-A56C-00AA003668DC}#1.1#0"; "MSMASK32.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "tabctl32.ocx"
Begin VB.Form frmTimeCardExpense 
   Caption         =   "Time Card Expense"
   ClientHeight    =   5490
   ClientLeft      =   1110
   ClientTop       =   345
   ClientWidth     =   7470
   Icon            =   "frmTimeCardExpense.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "TimeCardExpense"
   MDIChild        =   -1  'True
   ScaleHeight     =   5490
   ScaleWidth      =   7470
   Begin VB.Label lblLabels 
      Caption         =   "Expense Amount:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   0
      Left            =   150
      TabIndex        =   2
      Top             =   510
      Width           =   1815
   End
   Begin VB.TextBox ExpenseAmount
      Alignment       =   1 
      Height          =   315
      Left            =   2070
      TabIndex        =   1
      Top             =   510
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Expense Code:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   1
      Left            =   150
      TabIndex        =   4
      Top             =   835
      Width           =   1815
   End  
   Begin VB.ComboBox ExpenseCodeID 
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   2070
      TabIndex        =   3
      Top             =   835
      Width           =   3375
   End 
   Begin VB.Label lblLabels 
      Caption         =   "Expense Description:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   2
      Left            =   150
      TabIndex        =   6
      Top             =   1160
      Width           =   1815
   End
   Begin VB.TextBox ExpenseDescription
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   5
      Top             =   1160
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Project ID:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   3
      Left            =   150
      TabIndex        =   8
      Top             =   1485
      Width           =   1815
   End  
   Begin VB.ComboBox ProjectID 
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   2070
      TabIndex        =   7
      Top             =   1485
      Width           =   3375
   End 
   Begin VB.Label lblLabels 
      Caption         =   "Time Card Expense ID(Auto):"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   4
      Left            =   150
      TabIndex        =   10
      Top             =   1810
      Width           =   1815
   End
   Begin VB.TextBox TimeCardExpenseID
      BackColor       =   &H8000000F&
      Enabled         =   0   'False 
      Alignment       =   1 
      Height          =   315
      Left            =   2070
      TabIndex        =   9
      Top             =   1810
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Time Card ID:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   5
      Left            =   150
      TabIndex        =   12
      Top             =   2135
      Width           =   1815
   End  
   Begin VB.ComboBox TimeCardID 
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   2070
      TabIndex        =   11
      Top             =   2135
      Width           =   3375
   End 
   Begin VB.Label lblLabels 
      Caption         =   "Expense Date:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   6
      Left            =   150
      TabIndex        =   14
      Top             =   2460
      Width           =   1815
   End   
   Begin MSComCtl2.DTPicker ExpenseDate 
      Height          =   315
      Left            =   2070
      TabIndex        =   13
      Top             =   2460
      Width           =   3375
      _ExtentX        =   6006
      _ExtentY        =   503
      _Version        =   393216
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Format          =   60948481
      CurrentDate     =   36877
   End 
   Begin TimeBillingUI.CaptionBar CaptionBar1 
      Align           =   1  'Align Top
      Height          =   435
      Left            =   0
      TabIndex        =   5
      Top             =   0
      Width           =   7470
      _extentx        =   13176
      _extenty        =   767
      border          =   4
      forecolor       =   -2147483643
      Caption         =   "ok i am here"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   10.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty SubCaptionFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End   
End
Attribute VB_Name = "frmTimeCardExpense"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Implements iForm
Private Const mcstrMod$ = "frmTimeCardExpense"
Private m_TimeCardExpense As COMEXDataSourceSingle, m_Store As COMEXDataSourceSingle
Private m_flgLoading As Boolean
Private m_EnableAttr As ToolBarItems
Private m_Guid As String

Public Sub Component(vTimeCardExpense As COMEXDataSourceSingle)
    Set m_TimeCardExpense = vTimeCardExpense
    Set m_Store = m_TimeCardExpense.CopyMe
    LoadRecords
End Sub

Private Sub EnableToolbar(ByVal Dirty As Boolean)
    On Error Resume Next
    If Not Dirty Then
        If m_EnableAttr And tbSave Then m_EnableAttr = m_EnableAttr Xor tbSave
        If m_EnableAttr And tbCancel Then m_EnableAttr = m_EnableAttr Xor tbCancel
        If Not (m_EnableAttr And tbRefresh) Then m_EnableAttr = m_EnableAttr Or tbRefresh
    Else
        If Not (m_EnableAttr And tbSave) Then m_EnableAttr = m_EnableAttr Or tbSave
        If Not (m_EnableAttr And tbCancel) Then m_EnableAttr = m_EnableAttr Or tbCancel
        If m_EnableAttr And tbRefresh Then m_EnableAttr = m_EnableAttr Xor tbRefresh
    End If
    m_Toolbar.RefreshEnabledState
End Sub

Private Sub LoadRecords()
    On Error GoTo Err_LoadRecords
    
    Dim ctl As Control, i As Long 
    
    m_flgLoading = True
    
    
    
    With m_TimeCardExpense
        For i = 1 To .GetFieldCount
            On Error Resume Next
            Set ctl = Controls(.GetFieldName(i))
            If Err = 0 Then
                Select Case TypeName(ctl)
                    Case "Label"
                    Case "TextBox", "ComboBox", "MaskEdBox"
                        ctl = .GetData(i)
                    Case "CheckBox"
                    	ctl.Value = abs(.GetData(i))
                    Case "DTPicker"
                        ctl.Value = .GetData(i)
                End Select
            End If
        Next
    End With
    
    m_EnableAttr = iForm_Attributes
    EnableToolbar False
    m_flgLoading = False
Done_LoadRecords:
    Exit Sub
Err_LoadRecords:
    ErrorMsg Err.Number, Err.Description, "LoadRecords", mcstrMod
    Resume Done_LoadRecords
End Sub

 
Private Sub ExpenseAmount_Change()
    On Error GoTo Err_ExpenseAmount_Change
    If m_flgLoading Then Exit Sub
    m_TimeCardExpense.SetDatabyname ExpenseAmount.Name, ExpenseAmount
    EnableToolbar True
    Exit Sub
Err_ExpenseAmount_Change:
    With ExpenseAmount
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_TimeCardExpense.GetDataByName(ExpenseAmount.Name)
    End With
End Sub
Private Sub ExpenseAmount_LostFocus()
    On Error Resume Next
    ExpenseAmount = m_TimeCardExpense.GetDataByName(ExpenseAmount.Name)
End Sub

Private Sub ExpenseCodeID_Click()
    On Error GoTo Err_ExpenseCodeID_Click
    m_TimeCardExpense.SetDatabyname ExpenseCodeID.Name, ExpenseCodeID
    EnableToolbar True
    Exit Sub
Err_ExpenseCodeID_Click:
    ExpenseCodeID = m_TimeCardExpense.GetDatabyname(ExpenseCodeID.Name)
End Sub 
Private Sub ExpenseCodeID_LostFocus()
    On Error Resume Next
    ExpenseCodeID = m_TimeCardExpense.GetDataByName(ExpenseCodeID.Name)
End Sub
 
Private Sub ExpenseDescription_Change()
    On Error GoTo Err_ExpenseDescription_Change
    If m_flgLoading Then Exit Sub
    m_TimeCardExpense.SetDatabyname ExpenseDescription.Name, ExpenseDescription
    EnableToolbar True
    Exit Sub
Err_ExpenseDescription_Change:
    With ExpenseDescription
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_TimeCardExpense.GetDataByName(ExpenseDescription.Name)
    End With
End Sub
Private Sub ExpenseDescription_LostFocus()
    On Error Resume Next
    ExpenseDescription = m_TimeCardExpense.GetDataByName(ExpenseDescription.Name)
End Sub

Private Sub ProjectID_Click()
    On Error GoTo Err_ProjectID_Click
    m_TimeCardExpense.SetDatabyname ProjectID.Name, ProjectID
    EnableToolbar True
    Exit Sub
Err_ProjectID_Click:
    ProjectID = m_TimeCardExpense.GetDatabyname(ProjectID.Name)
End Sub 
Private Sub ProjectID_LostFocus()
    On Error Resume Next
    ProjectID = m_TimeCardExpense.GetDataByName(ProjectID.Name)
End Sub
 
Private Sub TimeCardExpenseID_Change()
    On Error GoTo Err_TimeCardExpenseID_Change
    If m_flgLoading Then Exit Sub
    m_TimeCardExpense.SetDatabyname TimeCardExpenseID.Name, TimeCardExpenseID
    EnableToolbar True
    Exit Sub
Err_TimeCardExpenseID_Change:
    With TimeCardExpenseID
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_TimeCardExpense.GetDataByName(TimeCardExpenseID.Name)
    End With
End Sub
Private Sub TimeCardExpenseID_LostFocus()
    On Error Resume Next
    TimeCardExpenseID = m_TimeCardExpense.GetDataByName(TimeCardExpenseID.Name)
End Sub

Private Sub TimeCardID_Click()
    On Error GoTo Err_TimeCardID_Click
    m_TimeCardExpense.SetDatabyname TimeCardID.Name, TimeCardID
    EnableToolbar True
    Exit Sub
Err_TimeCardID_Click:
    TimeCardID = m_TimeCardExpense.GetDatabyname(TimeCardID.Name)
End Sub 
Private Sub TimeCardID_LostFocus()
    On Error Resume Next
    TimeCardID = m_TimeCardExpense.GetDataByName(TimeCardID.Name)
End Sub

Private Sub ExpenseDate_Change()
    On Error GoTo Err_ExpenseDate_Change
    If m_flgLoading Then Exit Sub
    m_TimeCardExpense.SetDatabyname ExpenseDate.Name, ExpenseDate.Value
    EnableToolbar True
    Exit Sub
Err_ExpenseDate_Change:
    With ExpenseDate
        .Value = m_TimeCardExpense.GetDatabyname(ExpenseDate.Name)
    End With
End Sub
Private Sub ExpenseDate_LostFocus()
    On Error Resume Next
    ExpenseDate = m_TimeCardExpense.GetDataByName(ExpenseDate.Name)
End Sub



Private Sub Form_Activate()
    m_Toolbar.Activate m_Guid
End Sub

Private Sub Form_Load()
	Dim vTimeCardExpense As New TimeCardExpense, strCombo As String
    m_Guid = GUID
    m_Toolbar.Attach Me, m_Guid

    CaptionBar1.Caption = Caption
    Set CaptionBar1.Picture = Me.Icon
    
   	strCombo = vTimeCardExpense.GetExpenseCodesList
    FillCombo ExpenseCodeID, strCombo
    ExpenseCodeID.Tag = strCombo    
   	strCombo = vTimeCardExpense.GetProjectsList
    FillCombo ProjectID, strCombo
    ProjectID.Tag = strCombo    
   	strCombo = vTimeCardExpense.GetTimeCardsList
    FillCombo TimeCardID, strCombo
    TimeCardID.Tag = strCombo    
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    If m_EnableAttr And tbSave Then
        Select Case MsgBox("Record has been changed. Do you want To save it?" _
            , vbYesNoCancel + vbQuestion)
            Case vbYes
                m_TimeCardExpense.Save
            Case vbNo
            Case vbCancel
                Cancel = True
        End Select
    End If
End Sub

Private Sub Form_Resize()    
	On Error Resume Next	
	If Me.WindowState <> vbMinimized Then
	    With CaptionBar1
	        .Move 0, .Top, Me.ScaleWidth, .Height
	    End With           
	End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    m_Toolbar.Detach m_Guid
End Sub

Private Sub iForm_MainMenu()
    'n/a
End Sub

Private Property Get iForm_Attributes() As ToolBarItems
    iForm_Attributes = tbCancel + tbCloseMe + tbRefresh + tbSave  
End Property

Private Sub iForm_Cancel()
    Set m_TimeCardExpense = m_Store.CopyMe
    LoadRecords
End Sub

Private Sub iForm_CloseMe()
    Unload Me
End Sub

Private Sub iForm_delete()
    'n/a
End Sub

Private Property Get iForm_EnableAttributes() As ToolBarItems
    iForm_EnableAttributes = m_EnableAttr
End Property

Private Sub iForm_Find(ByVal Key As String)
    'n/a
End Sub

Private Sub iForm_Refresh()
    Dim aTimeCardExpense As TimeCardExpense
    Set aTimeCardExpense = m_TimeCardExpense
    aTimeCardExpense.Load aTimeCardExpense.TimeCardExpenseID
    Set m_TimeCardExpense = aTimeCardExpense
    LoadRecords
End Sub

Private Function iForm_Save() As Boolean
    If m_TimeCardExpense.Save Then 
    	Set m_Store = m_TimeCardExpense.CopyMe
    	iForm_Refresh
    End If
End Function

Private Sub iForm_AddNew()
    'n/a
End Sub

Private Sub iForm_ShowFormView()   
	'n/a
End Sub

Private Property Get iForm_FindSubTools() As cFindSubTools
    'n/a
End Property

Private Sub iForm_HelpAbout()
    'n/a
End Sub

Private Function iForm_OpenDB() As Boolean
    'n/a
End Function

Private Sub iForm_DeleteRow()
    'n/a
End Sub

Private Sub iForm_PrintOut()
    'n/a
End Sub