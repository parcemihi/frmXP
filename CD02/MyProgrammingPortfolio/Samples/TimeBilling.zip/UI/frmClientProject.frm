VERSION 5.00
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "mscomct2.ocx"
Object = "{C932BA88-4374-101B-A56C-00AA003668DC}#1.1#0"; "MSMASK32.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "tabctl32.ocx"
Begin VB.Form frmClientProject 
   Caption         =   "Project"
   ClientHeight    =   5490
   ClientLeft      =   1110
   ClientTop       =   345
   ClientWidth     =   7470
   Icon            =   "frmClientProject.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "ClientProject"
   MDIChild        =   -1  'True
   ScaleHeight     =   5490
   ScaleWidth      =   7470
   Begin VB.Label lblLabels 
      Caption         =   "Client ID:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   0
      Left            =   150
      TabIndex        =   2
      Top             =   510
      Width           =   1815
   End  
   Begin VB.ComboBox ClientID 
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   2070
      TabIndex        =   1
      Top             =   510
      Width           =   3375
   End 
   Begin VB.Label lblLabels 
      Caption         =   "Employee:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   1
      Left            =   150
      TabIndex        =   4
      Top             =   835
      Width           =   1815
   End  
   Begin VB.ComboBox EmployeeID 
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   2070
      TabIndex        =   3
      Top             =   835
      Width           =   3375
   End 
   Begin VB.Label lblLabels 
      Caption         =   "Project Description:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   2
      Left            =   150
      TabIndex        =   6
      Top             =   1160
      Width           =   1815
   End
   Begin VB.TextBox ProjectDescription
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   5
      Top             =   1160
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Project End Date:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   3
      Left            =   150
      TabIndex        =   8
      Top             =   1485
      Width           =   1815
   End   
   Begin MSComCtl2.DTPicker ProjectEndDate 
      Height          =   315
      Left            =   2070
      TabIndex        =   7
      Top             =   1485
      Width           =   3375
      _ExtentX        =   6006
      _ExtentY        =   503
      _Version        =   393216
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      CheckBox        =   -1  'True
      Format          =   60948481
      CurrentDate     =   36877
   End 
   Begin VB.Label lblLabels 
      Caption         =   "Project ID(Auto):"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   4
      Left            =   150
      TabIndex        =   10
      Top             =   1810
      Width           =   1815
   End
   Begin VB.TextBox ProjectID
      BackColor       =   &H8000000F&
      Enabled         =   0   'False 
      Alignment       =   1 
      Height          =   315
      Left            =   2070
      TabIndex        =   9
      Top             =   1810
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Project Name:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   5
      Left            =   150
      TabIndex        =   12
      Top             =   2135
      Width           =   1815
   End
   Begin VB.TextBox ProjectName
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   11
      Top             =   2135
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Total Billing Estimate:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   6
      Left            =   150
      TabIndex        =   14
      Top             =   2460
      Width           =   1815
   End
   Begin VB.TextBox ProjectTotalBillingEstimate
      Alignment       =   1 
      Height          =   315
      Left            =   2070
      TabIndex        =   13
      Top             =   2460
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Purchase Order Number:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   7
      Left            =   150
      TabIndex        =   16
      Top             =   2785
      Width           =   1815
   End
   Begin VB.TextBox PurchaseOrderNumber
      Alignment       =   0 
      Height          =   315
      Left            =   2070
      TabIndex        =   15
      Top             =   2785
      Width           =   3375
   End  
   Begin VB.Label lblLabels 
      Caption         =   "Project Begin Date:"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   8
      Left            =   150
      TabIndex        =   18
      Top             =   3110
      Width           =   1815
   End   
   Begin MSComCtl2.DTPicker ProjectBeginDate 
      Height          =   315
      Left            =   2070
      TabIndex        =   17
      Top             =   3110
      Width           =   3375
      _ExtentX        =   6006
      _ExtentY        =   503
      _Version        =   393216
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Format          =   60948481
      CurrentDate     =   36877
   End 
   Begin TabDlg.SSTab tabListview 
      Height          =   2895
      Left            =   0
      TabIndex        =   0
      Top             =   3435
      Width           =   7395
      _ExtentX        =   13044
      _ExtentY        =   5106
      _Version        =   393216
      TabOrientation  =   1
      Tabs            =   3
      TabHeight       =   520 
      TabCaption(0)   =   "Project Time Card Hours"
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "DataEditGrid1(0)"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).ControlCount=   1 
      TabCaption(1)   =   "Project Time Card Expenses"
      Tab(1).ControlEnabled=   0   'False 
      Tab(1).Control(0)=   "DataEditGrid1(1)"
      Tab(1).Control(0).Enabled=   0   'False
      Tab(1).ControlCount=   1 
      TabCaption(2)   =   "Payments"
      Tab(2).ControlEnabled=   0   'False 
      Tab(2).Control(0)=   "DataEditGrid1(2)"
      Tab(2).Control(0).Enabled=   0   'False
      Tab(2).ControlCount=   1       
      Begin TimeBillingUI.DataEditGrid DataEditGrid1 
         Height          =   2145
         Index           =   0
         Left            =   150
         TabIndex        =   1
         Top             =   180
         Width           =   6900
         _extentx        =   12171
         _extenty        =   3784
         AllowAddNew     =   -1
         Grouped         =   0   'False
      End      
      Begin TimeBillingUI.DataEditGrid DataEditGrid1 
         Height          =   2145
         Index           =   1
         Left            =   -74850
         TabIndex        =   1
         Top             =   180
         Width           =   6900
         _extentx        =   12171
         _extenty        =   3784
         AllowAddNew     =   -1
         Grouped         =   0   'False
      End      
      Begin TimeBillingUI.DataEditGrid DataEditGrid1 
         Height          =   2145
         Index           =   2
         Left            =   -74850
         TabIndex        =   1
         Top             =   180
         Width           =   6900
         _extentx        =   12171
         _extenty        =   3784
         AllowAddNew     =   -1
         Grouped         =   0   'False
      End
   End
   Begin TimeBillingUI.CaptionBar CaptionBar1 
      Align           =   1  'Align Top
      Height          =   435
      Left            =   0
      TabIndex        =   5
      Top             =   0
      Width           =   7470
      _extentx        =   13176
      _extenty        =   767
      border          =   4
      forecolor       =   -2147483643
      Caption         =   "ok i am here"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   10.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty SubCaptionFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End   
End
Attribute VB_Name = "frmClientProject"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Implements iForm
Private Const mcstrMod$ = "frmClientProject"
Private m_ClientProject As COMEXDataSourceSingle, m_Store As COMEXDataSourceSingle
Private m_flgLoading As Boolean
Private m_EnableAttr As ToolBarItems
Private m_Guid As String

Public Sub Component(vClientProject As COMEXDataSourceSingle)
    Set m_ClientProject = vClientProject
    Set m_Store = m_ClientProject.CopyMe
    LoadRecords
End Sub

Private Sub EnableToolbar(ByVal Dirty As Boolean)
    On Error Resume Next
    If Not Dirty Then
        If m_EnableAttr And tbSave Then m_EnableAttr = m_EnableAttr Xor tbSave
        If m_EnableAttr And tbCancel Then m_EnableAttr = m_EnableAttr Xor tbCancel
        If Not (m_EnableAttr And tbRefresh) Then m_EnableAttr = m_EnableAttr Or tbRefresh
    Else
        If Not (m_EnableAttr And tbSave) Then m_EnableAttr = m_EnableAttr Or tbSave
        If Not (m_EnableAttr And tbCancel) Then m_EnableAttr = m_EnableAttr Or tbCancel
        If m_EnableAttr And tbRefresh Then m_EnableAttr = m_EnableAttr Xor tbRefresh
    End If
    m_Toolbar.RefreshEnabledState
End Sub

Private Sub LoadRecords()
    On Error GoTo Err_LoadRecords
    
    Dim ctl As Control, i As Long 
    
    m_flgLoading = True
    
    Dim aClientProject As ClientProject
    Set aClientProject = m_ClientProject
    
    
    Dim vProjTimeCardHours As COMEXDataSource
    Set vProjTimeCardHours = aClientProject.ProjTimeCardHours
    
    Dim vProjTimeCardExpenses As COMEXDataSource
    Set vProjTimeCardExpenses = aClientProject.ProjTimeCardExpenses
    
    Dim vPayments As COMEXDataSource
    Set vPayments = aClientProject.Payments
    
    
    With m_ClientProject
        For i = 1 To .GetFieldCount
            On Error Resume Next
            Set ctl = Controls(.GetFieldName(i))
            If Err = 0 Then
                Select Case TypeName(ctl)
                    Case "Label"
                    Case "TextBox", "ComboBox", "MaskEdBox"
                        ctl = .GetData(i)
                    Case "CheckBox"
                    	ctl.Value = abs(.GetData(i))
                    Case "DTPicker"
                        ctl.Value = .GetData(i)
                End Select
            End If
        Next
    End With
    
    Set Me.DataEditGrid1(0).DataSource = vProjTimeCardHours
    Set Me.DataEditGrid1(1).DataSource = vProjTimeCardExpenses
    Set Me.DataEditGrid1(2).DataSource = vPayments
    m_EnableAttr = iForm_Attributes
    EnableToolbar False
    m_flgLoading = False
Done_LoadRecords:
    Exit Sub
Err_LoadRecords:
    ErrorMsg Err.Number, Err.Description, "LoadRecords", mcstrMod
    Resume Done_LoadRecords
End Sub


Private Sub ClientID_Click()
    On Error GoTo Err_ClientID_Click
    m_ClientProject.SetDatabyname ClientID.Name, ClientID
    EnableToolbar True
    Exit Sub
Err_ClientID_Click:
    ClientID = m_ClientProject.GetDatabyname(ClientID.Name)
End Sub 
Private Sub ClientID_LostFocus()
    On Error Resume Next
    ClientID = m_ClientProject.GetDataByName(ClientID.Name)
End Sub

Private Sub EmployeeID_Click()
    On Error GoTo Err_EmployeeID_Click
    m_ClientProject.SetDatabyname EmployeeID.Name, EmployeeID
    EnableToolbar True
    Exit Sub
Err_EmployeeID_Click:
    EmployeeID = m_ClientProject.GetDatabyname(EmployeeID.Name)
End Sub 
Private Sub EmployeeID_LostFocus()
    On Error Resume Next
    EmployeeID = m_ClientProject.GetDataByName(EmployeeID.Name)
End Sub
 
Private Sub ProjectDescription_Change()
    On Error GoTo Err_ProjectDescription_Change
    If m_flgLoading Then Exit Sub
    m_ClientProject.SetDatabyname ProjectDescription.Name, ProjectDescription
    EnableToolbar True
    Exit Sub
Err_ProjectDescription_Change:
    With ProjectDescription
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_ClientProject.GetDataByName(ProjectDescription.Name)
    End With
End Sub
Private Sub ProjectDescription_LostFocus()
    On Error Resume Next
    ProjectDescription = m_ClientProject.GetDataByName(ProjectDescription.Name)
End Sub

Private Sub ProjectEndDate_Change()
    On Error GoTo Err_ProjectEndDate_Change
    If m_flgLoading Then Exit Sub
    m_ClientProject.SetDatabyname ProjectEndDate.Name, ProjectEndDate.Value
    EnableToolbar True
    Exit Sub
Err_ProjectEndDate_Change:
    With ProjectEndDate
        .Value = m_ClientProject.GetDatabyname(ProjectEndDate.Name)
    End With
End Sub
Private Sub ProjectEndDate_LostFocus()
    On Error Resume Next
    ProjectEndDate = m_ClientProject.GetDataByName(ProjectEndDate.Name)
End Sub
 
Private Sub ProjectID_Change()
    On Error GoTo Err_ProjectID_Change
    If m_flgLoading Then Exit Sub
    m_ClientProject.SetDatabyname ProjectID.Name, ProjectID
    EnableToolbar True
    Exit Sub
Err_ProjectID_Change:
    With ProjectID
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_ClientProject.GetDataByName(ProjectID.Name)
    End With
End Sub
Private Sub ProjectID_LostFocus()
    On Error Resume Next
    ProjectID = m_ClientProject.GetDataByName(ProjectID.Name)
End Sub
 
Private Sub ProjectName_Change()
    On Error GoTo Err_ProjectName_Change
    If m_flgLoading Then Exit Sub
    m_ClientProject.SetDatabyname ProjectName.Name, ProjectName
    EnableToolbar True
    Exit Sub
Err_ProjectName_Change:
    With ProjectName
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_ClientProject.GetDataByName(ProjectName.Name)
    End With
End Sub
Private Sub ProjectName_LostFocus()
    On Error Resume Next
    ProjectName = m_ClientProject.GetDataByName(ProjectName.Name)
End Sub
 
Private Sub ProjectTotalBillingEstimate_Change()
    On Error GoTo Err_ProjectTotalBillingEstimate_Change
    If m_flgLoading Then Exit Sub
    m_ClientProject.SetDatabyname ProjectTotalBillingEstimate.Name, ProjectTotalBillingEstimate
    EnableToolbar True
    Exit Sub
Err_ProjectTotalBillingEstimate_Change:
    With ProjectTotalBillingEstimate
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_ClientProject.GetDataByName(ProjectTotalBillingEstimate.Name)
    End With
End Sub
Private Sub ProjectTotalBillingEstimate_LostFocus()
    On Error Resume Next
    ProjectTotalBillingEstimate = m_ClientProject.GetDataByName(ProjectTotalBillingEstimate.Name)
End Sub
 
Private Sub PurchaseOrderNumber_Change()
    On Error GoTo Err_PurchaseOrderNumber_Change
    If m_flgLoading Then Exit Sub
    m_ClientProject.SetDatabyname PurchaseOrderNumber.Name, PurchaseOrderNumber
    EnableToolbar True
    Exit Sub
Err_PurchaseOrderNumber_Change:
    With PurchaseOrderNumber
        .SelStart = 0
        .SelLength = Len(.Text)
        .SelText = m_ClientProject.GetDataByName(PurchaseOrderNumber.Name)
    End With
End Sub
Private Sub PurchaseOrderNumber_LostFocus()
    On Error Resume Next
    PurchaseOrderNumber = m_ClientProject.GetDataByName(PurchaseOrderNumber.Name)
End Sub

Private Sub ProjectBeginDate_Change()
    On Error GoTo Err_ProjectBeginDate_Change
    If m_flgLoading Then Exit Sub
    m_ClientProject.SetDatabyname ProjectBeginDate.Name, ProjectBeginDate.Value
    EnableToolbar True
    Exit Sub
Err_ProjectBeginDate_Change:
    With ProjectBeginDate
        .Value = m_ClientProject.GetDatabyname(ProjectBeginDate.Name)
    End With
End Sub
Private Sub ProjectBeginDate_LostFocus()
    On Error Resume Next
    ProjectBeginDate = m_ClientProject.GetDataByName(ProjectBeginDate.Name)
End Sub



Private Sub tabListview_Click(PreviousTab As Integer)
	
  Me.DataEditGrid1(0).Visible =(tabListview.tab = 0)
  Me.DataEditGrid1(1).Visible =(tabListview.tab = 1)
  Me.DataEditGrid1(2).Visible =(tabListview.tab = 2)
  Me.Refresh
End Sub

Private Sub DataEditGrid1_Dirty(Index As Integer)
    EnableToolbar True
End Sub

Private Sub DataEditGrid1_FetchColumnSetup(Index As Integer, ColName As String, ControlType As FieldControlType, ComboMaskList As String, Alignment As FieldControlAlign, Hidden As Boolean, AutoNumber As Boolean)
    Select Case Index    
        Case 0
            Select Case ColName
                Case "ProjectID"
                    Hidden = True
            End Select
            Dim vProjTimeCardHour As New ProjTimeCardHour
            Select Case ColName 
                Case "BillableHours"
                    ColName = "Billable Hours"
                    AutoNumber = False
                    Alignment = 2
                Case "BillingRate"
                    ColName = "Billing Rate"
                    AutoNumber = False
                    Alignment = 2
                Case "ProjectID"
                    ColName = "Project ID"
                    AutoNumber = False
                    Alignment = 1
                    ControlType = fcComboBx
                    ComboMaskList = vProjTimeCardHour.GetProjectsList
                Case "TimeCardDetailID"
                    ColName = "TimeCard Detail ID"
                    AutoNumber = True
                    Alignment = 1
                Case "TimeCardID"
                    ColName = "TimeCard ID"
                    AutoNumber = False
                    Alignment = 2
                    ControlType = fcComboBx
                    ComboMaskList = vProjTimeCardHour.GetTimeCardsList
                Case "WorkCodeID"
                    ColName = "Work Code"
                    AutoNumber = False
                    Alignment = 1
                    ControlType = fcComboBx
                    ComboMaskList = vProjTimeCardHour.GetWorkCodesList
                Case "WorkDescription"
                    ColName = "Work Description"
                    AutoNumber = False
                    Alignment = 0			
                Case "DateWorked"
                    ColName = "Date Worked"
                    AutoNumber = False
                    Alignment = 1
                    ControlType = fcDateTimePick
            End Select    
        Case 1
            Select Case ColName
                Case "ProjectID"
                    Hidden = True
            End Select
            Dim vProjTimeCardExpense As New ProjTimeCardExpense
            Select Case ColName 
                Case "ExpenseAmount"
                    ColName = "Expense Amount"
                    AutoNumber = False
                    Alignment = 2
                Case "ExpenseCodeID"
                    ColName = "Expense Code"
                    AutoNumber = False
                    Alignment = 0
                    ControlType = fcComboBx
                    ComboMaskList = vProjTimeCardExpense.GetExpenseCodesList
                Case "ExpenseDescription"
                    ColName = "Expense Description"
                    AutoNumber = False
                    Alignment = 0
                Case "ProjectID"
                    ColName = "Project ID"
                    AutoNumber = False
                    Alignment = 2
                    ControlType = fcComboBx
                    ComboMaskList = vProjTimeCardExpense.GetProjectsList
                Case "TimeCardExpenseID"
                    ColName = "TimeCard Expense ID"
                    AutoNumber = True
                    Alignment = 2
                Case "TimeCardID"
                    ColName = "TimeCard ID"
                    AutoNumber = False
                    Alignment = 2
                    ControlType = fcComboBx
                    ComboMaskList = vProjTimeCardExpense.GetTimeCardsList			
                Case "ExpenseDate"
                    ColName = "Expense Date"
                    AutoNumber = False
                    Alignment = 1
                    ControlType = fcDateTimePick
            End Select    
        Case 2
            Select Case ColName
                Case "ProjectID"
                    Hidden = True
            End Select
            Dim vPayment As New Payment
            Select Case ColName 
                Case "CardholdersName"
                    ColName = "Cardholders Name"
                    AutoNumber = False
                    Alignment = 0
                Case "CreditCardNumber"
                    ColName = "CreditCard Number"
                    AutoNumber = False
                    Alignment = 0
                Case "PaymentAmount"
                    ColName = "Payment Amount"
                    AutoNumber = False
                    Alignment = 2
                Case "PaymentID"
                    ColName = "Payment ID"
                    AutoNumber = True
                    Alignment = 2
                Case "PaymentMethodID"
                    ColName = "Payment Method"
                    AutoNumber = False
                    Alignment = 0
                    ControlType = fcComboBx
                    ComboMaskList = vPayment.GetPaymentMethodsList
                Case "ProjectID"
                    ColName = "Project ID"
                    AutoNumber = False
                    Alignment = 1
                    ControlType = fcComboBx
                    ComboMaskList = vPayment.GetProjectsList			
                Case "CreditCardExpDate"
                    ColName = "CreditCard Expire Date"
                    AutoNumber = False
                    Alignment = 1
                    ControlType = fcDateTimePick			
                Case "PaymentDate"
                    ColName = "Payment Date"
                    AutoNumber = False
                    Alignment = 1
                    ControlType = fcDateTimePick
            End Select
    End Select	
End Sub

Private Sub Form_Activate()
    m_Toolbar.Activate m_Guid
End Sub

Private Sub Form_Load()
	Dim vClientProject As New ClientProject, strCombo As String
    m_Guid = GUID
    m_Toolbar.Attach Me, m_Guid

    tabListview_Click 0 
	ThinBorder DataEditGrid1(0).hwnd, False 
	ThinBorder DataEditGrid1(1).hwnd, False 
	ThinBorder DataEditGrid1(2).hwnd, False 
    CaptionBar1.Caption = Caption
    Set CaptionBar1.Picture = Me.Icon
    
   	strCombo = vClientProject.GetClientsList
    FillCombo ClientID, strCombo
    ClientID.Tag = strCombo    
   	strCombo = vClientProject.GetEmployeesList
    FillCombo EmployeeID, strCombo
    EmployeeID.Tag = strCombo    
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    If m_EnableAttr And tbSave Then
        Select Case MsgBox("Record has been changed. Do you want To save it?" _
            , vbYesNoCancel + vbQuestion)
            Case vbYes
                m_ClientProject.Save
            Case vbNo
            Case vbCancel
                Cancel = True
        End Select
    End If
End Sub

Private Sub Form_Resize()    
	On Error Resume Next	
	If Me.WindowState <> vbMinimized Then
	    With CaptionBar1
	        .Move 0, .Top, Me.ScaleWidth, .Height
	    End With 
	    With tabListview
	        .Left = 0
	        .Top = (ProjectBeginDate.Top + ProjectBeginDate.Height + 100)
	        .Height = Me.ScaleHeight - .Top
	        .Width = Me.ScaleWidth
	        DataEditGrid1(0).Move 100, 100, .Width - 200, .Height - 450
	        DataEditGrid1(1).Move 100, 100, .Width - 200, .Height - 450
	        DataEditGrid1(2).Move 100, 100, .Width - 200, .Height - 450
	    End With          
	End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    m_Toolbar.Detach m_Guid
End Sub

Private Sub LoadFormView()
    On Error GoTo Err_LoadFormView
    Dim vItem As Object, frmX As Object , aClientProject As ClientProject
    
    Set aClientProject = m_ClientProject
    Select Case tabListview.Tab
       	Case 0      
       		Dim vProjTimeCardHour As ProjTimeCardHour
       		Set vItem = New ProjTimeCardHour
       		Set frmX = New frmProjTimeCardHour                                            
       		Set vProjTimeCardHour = aClientProject.ProjTimeCardHours(DataEditGrid1(tabListview.Tab).CurrentRecord)
       		vItem.Load vProjTimeCardHour.TimeCardDetailID
       	Case 1      
       		Dim vProjTimeCardExpense As ProjTimeCardExpense
       		Set vItem = New ProjTimeCardExpense
       		Set frmX = New frmProjTimeCardExpense                                            
       		Set vProjTimeCardExpense = aClientProject.ProjTimeCardExpenses(DataEditGrid1(tabListview.Tab).CurrentRecord)
       		vItem.Load vProjTimeCardExpense.TimeCardExpenseID
       	Case 2      
       		Dim vPayment As Payment
       		Set vItem = New Payment
       		Set frmX = New frmPayment                                            
       		Set vPayment = aClientProject.Payments(DataEditGrid1(tabListview.Tab).CurrentRecord)
       		vItem.Load vPayment.PaymentID    
    End Select    
    frmX.Component vItem
    frmX.Show
Done_LoadFormView:
    Exit Sub
Err_LoadFormView:
    If err <> 91 Then ErrorMsg Err.Number, Err.Description, "LoadFormView", mcstrMod
    Resume Done_LoadFormView
End Sub

Private Sub iForm_MainMenu()
    'n/a
End Sub

Private Property Get iForm_Attributes() As ToolBarItems
    iForm_Attributes = tbCancel + tbCloseMe + tbRefresh + tbSave   + tbDeleteRow + tbShowFormView
End Property

Private Sub iForm_Cancel()
    Set m_ClientProject = m_Store.CopyMe
    LoadRecords
End Sub

Private Sub iForm_CloseMe()
    Unload Me
End Sub

Private Sub iForm_delete()
    'n/a
End Sub

Private Property Get iForm_EnableAttributes() As ToolBarItems
    iForm_EnableAttributes = m_EnableAttr
End Property

Private Sub iForm_Find(ByVal Key As String)
    'n/a
End Sub

Private Sub iForm_Refresh()
    Dim aClientProject As ClientProject
    Set aClientProject = m_ClientProject
    aClientProject.Load aClientProject.ProjectID, True
    Set m_ClientProject = aClientProject
    LoadRecords
End Sub

Private Function iForm_Save() As Boolean
    DataEditGrid1(tabListview.Tab).Update
    If m_ClientProject.Save Then 
    	Set m_Store = m_ClientProject.CopyMe
    	iForm_Refresh
    End If
End Function

Private Sub iForm_AddNew()
    'n/a
End Sub

Private Sub iForm_ShowFormView()   
	LoadFormView
End Sub

Private Property Get iForm_FindSubTools() As cFindSubTools
    'n/a
End Property

Private Sub iForm_HelpAbout()
    'n/a
End Sub

Private Function iForm_OpenDB() As Boolean
    'n/a
End Function

Private Sub iForm_DeleteRow()
    DataEditGrid1(tabListview.Tab).delete    
End Sub

Private Sub iForm_PrintOut()
    'n/a
End Sub